########################################################################
# PURPOSE: Generic Functions                                           #
########################################################################
import sys
import os
sys.path.append('../')
sys.path.append('/home/hadoop/')
import time
import logging
import datetime
import os.path
import traceback
from pyspark import StorageLevel
import common.config as config

################################################  Function - registerSourceHiveTable ################################################  
# To Register hive external table as data frame
# The function accepts schema, table_name, col_name, co_nbr_list as input arguments and returns the data frame

def registerSourceHiveTable(hive_context, schema, table_name, col_name, key_cols='', orderby_cols='', filter='', isEmptyCheck_Flag='YES',removeDuplicate='YES'):
	
	filter_condition = ''
	hive_select_query="select {} from {}.{} {}) a where row_number=1".format(col_name, schema, table_name, filter_condition)
	
	temp_table_name="hive_{}_src".format(table_name)
	
	hive_data_frame=hive_context.sql(hive_select_query).na.fill("").na.fill(0)

	if isEmptyCheck_Flag.upper() == 'YES':
		if hive_data_frame.rdd.isEmpty():
			logging.info('There is no data in the source file to process, - %s', table_name)
			exit(0)	
	
	hive_data_frame.registerTempTable(temp_table_name)
	return hive_data_frame
#####################################################################################################################################

################################################  Function - initializeSparkHiveContext ################################################ 
# To initialize Spark Context and Hive Context
# Accepts Application Name as input and retruns hive_context

def initializeSparkHiveContext(application_name):
	from pyspark.sql import HiveContext
	from pyspark.sql import SparkSession
	from pyspark.sql import SQLContext

	spark = SparkSession.builder.master("yarn").appName(application_name).config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").config("spark.kryoserializer.buffer.max","126mb").enableHiveSupport().getOrCreate()
	sc = spark.sparkContext
	hive_context = HiveContext(sc)
        print 'spark/hive context'
	return hive_context
	
#####################################################################################################################################
