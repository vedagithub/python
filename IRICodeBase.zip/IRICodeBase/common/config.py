########################################################################
# PURPOSE: CONFIGURATION PARAMETERS 
# ENVIRONMENT:  DEV
#
########################################################################
import boto3

#Initializing the variables
#tempdir="s3://sysco-prod-seed-spark-redshift-temp-us-east-1/"

#url="jdbc:redshift://seed-prod-edw-cluster.cj0d40pq13x9.us-east-1.redshift.amazonaws.com:5439/seedpro?user=svc_etlload_pro?password=RsP_Sm31"


log_file_directory="/home/hadoop/log"
success_file_path ="/home/hadoop/jars/"

#s3_bucket="s3://sysco-prod-seed-edw-us-east-1"

coalesce_value=12

#----------------------
#Schema Variables	#
#----------------------

dataMartSchema = 'edwp' 

stageSchema= 'intp'

landingSchema= 'lndp'

tempSchema= 'temp'

srcHiveDatabase= 'consumer'
#riHiveDatabase= 'seed_ridata'

#-----------------
#Getting Temporary Key #
#------------------------
credentials=boto3.Session().get_credentials()
aws_access_key_id = credentials.access_key
aws_secret_access_key = credentials.secret_key
aws_session_token = credentials.token

emrDimObj=['CUST_SHIP_TO', 'CUST_CO_CUST_GRP', 'ITM_CO_ITM_CHRT', 'ITM_CO_ITM', 'ITM_CO_ITM_TRUE_VNDR', 'ITM_CO_ITM_VNDR', 'ITM_CO_ITM_VNDR_SHIP_FROM', 'VNDR_CO_VNDR']

infaDimObj=['AD_INFO', 'CUST_BIL_TO', 'CUST_MSTR_PRNT_CUST', 'CUST_MUA_CUST_GRP', 'CUST_MUA_CUST_GRP_LNK', 'CUST_SHIP_TO_AUX', 'ITM_BSCC_BUS_CTR', 'ITM_CO_ITM_TO_ITM', 'ITM_CO_ITM_WHSE_PARM', 'ITM', 'ITM_PROD_GRP_ITM', 'ORG_ENTY_DTL', 'ORG_CO', 'ORG_EMPLE_MSTR', 'ORG_FP_HIER', 'REFP', 'VNDR_CO_VNDR_SHIP_FROM', 'VNDR_CORP_BIL_PRC_PT_VNDR', 'VNDR', 'VNDR_SHIP_FROM','ITM_FWD_WHSE_CORP_BIL_VNDR_REL','ORG_FWD_WHSE_DIM ','CUST_CORP_CUST_DIM']



