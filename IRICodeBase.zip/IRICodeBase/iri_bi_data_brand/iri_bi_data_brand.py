 #################################################################################################################
##	Usage  : iri_bi_data_brand.py 	 	 			 
##										                             
##	Source : iri_bi_data_brand_raw							     			                              
##                                                                   
##	Target : iri_bi_data_brand_trans                        			 
##                                                                   
##	Purpose: APPLY THE BUSINESS LOGIC AND LOAD THE DATA INTO  
##           iri_bi_data_brand_trans TABLE								      
 ##################################################################### ############################################
import sys
sys.path.append('/home/hadoop/')
import time
import logging
import datetime
import os.path
import traceback
from pyspark import StorageLevel
import common.config as config
import common.common_func as common_func
import iri_bi_data_brand_sql as query_file


def registerHiveTable(hive_context):
	
	#Registering spark data frame for Source Hive table IRI_BI_DATA_BRAND_CLEANSED
	iri_bi_data_brand_data_frame = common_func.registerSourceHiveTable(hive_context, config.srcHiveDatabase,'iri_bi_data_brand_cleansed', '*', key_cols='', orderby_cols='Time_Key_Total')
	iri_bi_data_brand_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	return {'iri_bi_data_brand_data_frame':iri_bi_data_brand_data_frame}

def main():

	current_date=datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S')
	file_name=sys.argv[0].split('/')[-1].split('.')[0]
	
	log_file_path="{}/{}_{}.log".format(config.log_file_directory,file_name,current_date)
	logging.basicConfig(filename=log_file_path,filemode='w',level=logging.INFO)
	
	#Create Hive context
	hive_context = common_func.initializeSparkHiveContext('IRI_BI_DATA_BRAND')
	hive_context.sql("SET mapred.input.dir.recursive=true")
	
	#Registering Hive Table
	logging.info('Registering Hive Table')
	#iri_bi_data_brand_data_frame returns here
	map_dataframe=registerHiveTable(hive_context)
	SESS_STRT_TM=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')	
	
	iri_bi_data_brand_int_data_frame=hive_context.sql(query_file.iri_bi_data_brand_int_process_query)
	iri_bi_data_brand_int_data_frame.registerTempTable("IRI_BI_DATA_BRAND")			
	iri_bi_data_brand_int_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	for df in list(map_dataframe.values()) :
		df.unpersist()
	
	logging.info('Registering Intermediate Dataframe, End Time - %s', datetime.datetime.now())
			
	iri_bi_data_brand_int_data_frame.unpersist()

if __name__ == "__main__":
	try:
		main()
	except BaseException as error: 
		logging.error(traceback.format_exc())
		raise