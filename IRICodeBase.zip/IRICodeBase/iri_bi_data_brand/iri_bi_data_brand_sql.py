############################################# IRI_BI_DATA_BRAND Queries #################################################################

################################################ TRANSFORMATION QUERIES ##############################################

iri_bi_data_brand_int_process_query="""
SELECT * FROM hive_IRI_BI_DATA_BRAND_CLEANSED_src WHERE Time_Key_Total='2007'
"""