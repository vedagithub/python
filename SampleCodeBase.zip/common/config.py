########################################################################
# PURPOSE: CONFIGURATION PARAMETERS 
# ENVIRONMENT:  PRODUCTION
#
########################################################################
import boto3

#Initializing the variables
SparkRedshiftLib="com.databricks.spark.redshift"
tempdir="s3://sysco-prod-seed-spark-redshift-temp-us-east-1/"

url="jdbc:redshift://seed-prod-edw-cluster.cj0d40pq13x9.us-east-1.redshift.amazonaws.com:5439/seedpro?user=svc_etlload_pro?password=RsP_Sm31"


aurora_host="seed-aurora-prod-auroracluster-1958vkrhsmnmu.cluster-cssuntoy2gcy.us-east-1.rds.amazonaws.com"
aurora_username="seedadmin"
aurora_password="DBsecRet89842"
aurora_database="trackopco"

log_file_directory="/home/hadoop/log"
success_file_path ="/home/hadoop/jars/"

s3_bucket="s3://sysco-prod-seed-edw-us-east-1"

coalesce_value=12

#----------------------
#Schema Variables	#
#----------------------

dataMartSchema = 'edwp' 

stageSchema= 'intp'

landingSchema= 'lndp'

tempSchema= 'temp'

srcHiveDatabase= 'seed_sourcedata'
riHiveDatabase= 'seed_ridata'

#-----------------
#s3 Subfolders

salesMerchSubArea= 'Sales-Merchandising'
shareddimLoc= 'Shared-Dimension'
opcoLoc= 'OpcoData'

#------------------------
#Getting Temporary Key #
#------------------------
credentials=boto3.Session().get_credentials()
aws_access_key_id = credentials.access_key
aws_secret_access_key = credentials.secret_key
aws_session_token = credentials.token

s3FolderDetail = {'ITM_CO_ITM' : 'OpcoData/Shared-Dimension', 'REFP' : 'OpcoData/Shared-Dimension', 'ORG_ENTY_DTL' : 'OpcoData/Shared-Dimension', 'CUST_SHIP_TO' : 'OpcoData/Shared-Dimension', 'VNDR_CO_VNDR' : 'OpcoData/Shared-Dimension', 'CUST_CO_CUST_GRP' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_TO_ITM' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_VNDR' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_VNDR_SHIP_FROM' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_CHRT' : 'OpcoData/Shared-Dimension', 'VNDR_CO_VNDR_SHIP_FROM' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_WHSE_PARM' : 'OpcoData/Shared-Dimension', 'ITM_CO_ITM_TRUE_VNDR' : 'OpcoData/Shared-Dimension', 'CUST_BIL_TO' : 'OpcoData/Sales-Merchandising/Dimension', 'CUST_SHIP_TO_AUX' : 'OpcoData/Sales-Merchandising/Dimension', 'CUST_GAIN_LOSS' : 'OpcoData/Sales-Merchandising/Dimension', 'RTE_TO_CUST_EXCP' : 'OpcoData/Sales-Merchandising/Dimension', 'ITM_PROD_GRP_ITM' : 'OpcoData/Sales-Merchandising/Dimension', 'ITM_PROD_GRP' : 'OpcoData/Sales-Merchandising/Dimension', 'ORG_EMPLE_MSTR' : 'OpcoData/Sales-Merchandising/Dimension', 'SALE_FP_OBLIG_DTL' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_FP_OBLIG_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_ACCT_RECV_OBLIG_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_CUST_ORDR_DTL' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_CUST_ORDR_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_CUST_PRFT' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_OBLIG_DTL' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_OBLIG_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'NAT_EDI_CTL' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_TRUE_VNDR' : 'OpcoData/Sales-Merchandising/Fact', 'AGR_CUST_AGR_TRANS' : 'OpcoData/Sales-Merchandising/Fact', 'AGR_VNDR_AGR_TRANS' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_CUST_ORDR_AUD_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_CUST_ORDR_AUD_DTL' : 'OpcoData/Sales-Merchandising/Fact', 'ACORN_GL_J4TRANS' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_KPI_WK' : 'OpcoData/Sales-Merchandising/Fact', 'SALE_AUDIT_FACT_DAILY' : 'OpcoData/Sales-Merchandising/Fact', 'CUST_RATE' : 'OpcoData/Sales-Merchandising/Fact', 'PO_CO_PO_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'PO_CO_PO_DTL' : 'OpcoData/Sales-Merchandising/Fact', 'PO_CORP_PO_DTL' : 'CorpData/Dimension', 'PO_CORP_PO_HEAD' : 'CorpData/Dimension', 'PO_FP_PO_HEAD' : 'OpcoData/Sales-Merchandising/Fact', 'PO_FP_PO_DTL' : 'OpcoData/Sales-Merchandising/Fact','CUST_SHIP_TO_SYG' : 'OpcoData/Sygma','ITM_CO_ITM_SYG' : 'OpcoData/Sygma','SALE_OBLIG_DTL_SYG' : 'OpcoData/Sygma', 'SALE_OBLIG_HEAD_SYG' : 'OpcoData/Sygma', 'LOAD_HIST_FACT' : 'OpcoData/Shared-Dimension', 'LOAD_ERR_FACT' : 'OpcoData/Shared-Dimension'}

emrDimObj=['CUST_SHIP_TO', 'CUST_CO_CUST_GRP', 'ITM_CO_ITM_CHRT', 'ITM_CO_ITM', 'ITM_CO_ITM_TRUE_VNDR', 'ITM_CO_ITM_VNDR', 'ITM_CO_ITM_VNDR_SHIP_FROM', 'VNDR_CO_VNDR']

infaDimObj=['AD_INFO', 'CUST_BIL_TO', 'CUST_MSTR_PRNT_CUST', 'CUST_MUA_CUST_GRP', 'CUST_MUA_CUST_GRP_LNK', 'CUST_SHIP_TO_AUX', 'ITM_BSCC_BUS_CTR', 'ITM_CO_ITM_TO_ITM', 'ITM_CO_ITM_WHSE_PARM', 'ITM', 'ITM_PROD_GRP_ITM', 'ORG_ENTY_DTL', 'ORG_CO', 'ORG_EMPLE_MSTR', 'ORG_FP_HIER', 'REFP', 'VNDR_CO_VNDR_SHIP_FROM', 'VNDR_CORP_BIL_PRC_PT_VNDR', 'VNDR', 'VNDR_SHIP_FROM','ITM_FWD_WHSE_CORP_BIL_VNDR_REL','ORG_FWD_WHSE_DIM ','CUST_CORP_CUST_DIM']



