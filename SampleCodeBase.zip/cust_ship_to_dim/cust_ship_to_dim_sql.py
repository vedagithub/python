############################################# CUST_SHIP_TO_DIM Queries #################################################################
########################################################### RI Check Queries ############################################################

vndr_dim_ri_query = """
	SELECT CUST.VNDR_NBR ,CUST.SRC_CREAT_DT ,CUST.SESS_NM 
	FROM 
	(SELECT TRIM(VNDR_NBR) VNDR_NBR, 
	'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM hive_CUST_SHIP_TO_src WHERE TRIM(VNDR_NBR)<>'') CUST 
	LEFT OUTER JOIN (SELECT VNDR_NBR, '19000101' AS SRC_CREAT_DT, 's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM rs_VNDR_DIM_mstr) VNDR
	ON CUST.VNDR_NBR=VNDR.VNDR_NBR WHERE VNDR.VNDR_NBR IS NULL
	"""

vndr_ship_from_dim_ri_query = """
	SELECT VNDR1.VNDR_NBR,VNDR1.VNDR_SHIP_PT_NBR, VNDR1.SRC_CREAT_DT,VNDR1.SESS_NM 
	FROM 
	(SELECT TRIM(VNDR_NBR) VNDR_NBR,VNDR_SHIP_PT_NBR,'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM 
	FROM hive_CUST_SHIP_TO_src WHERE  TRIM(VNDR_NBR)<>'' AND VNDR_SHIP_PT_NBR<>0 )  VNDR1
	LEFT OUTER JOIN  
	(SELECT VNDR_NBR, VNDR_SHIP_PT_NBR, '19000101' AS SRC_CREAT_DT, 's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM rs_VNDR_SHIP_FROM_DIM_mstr A,
	rs_VNDR_DIM_mstr B WHERE A.VNDR_SKEY = B.VNDR_SKEY AND A.CURR_REC_IND='Y') VNDR2
	ON VNDR1.VNDR_NBR=VNDR2.VNDR_NBR AND VNDR1.VNDR_SHIP_PT_NBR=VNDR2.VNDR_SHIP_PT_NBR WHERE VNDR2.VNDR_NBR IS NULL AND VNDR2.VNDR_SHIP_PT_NBR IS NULL
	"""

cust_bil_to_dim_ri_query = """
	SELECT CST1.CO_NBR,CST1.BIL_TO_NBR, CST1.SRC_CREAT_DT, CST1.SESS_NM 
	FROM 
	(SELECT TRIM(CO_NBR) CO_NBR,TRIM(hive_CUST_SHIP_TO_src.BIL_TO_NBR) BIL_TO_NBR,'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM 
	FROM hive_CUST_SHIP_TO_src WHERE TRIM(hive_CUST_SHIP_TO_src.BIL_TO_NBR) <>'') CST1
	LEFT OUTER JOIN 
	(SELECT CO_NBR, A.BIL_TO_NBR,'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM rs_CUST_BIL_TO_DIM_mstr A,
	rs_ORG_CO_DIM_mstr CO WHERE A.CO_SKEY=CO.CO_SKEY AND A.CURR_REC_IND='Y') CST2 
	ON CST1.CO_NBR=CST2.CO_NBR AND CST1.BIL_TO_NBR=CST2.BIL_TO_NBR  WHERE CST2.CO_NBR IS NULL AND CST2.BIL_TO_NBR IS NULL
	"""

cust_mstr_prnt_cust_dim_ri_query = """
	SELECT CPM1.CO_NBR,CPM1.PRNT_CUST_NBR, CPM1.SRC_CREAT_DT, CPM1.SESS_NM 
	FROM(
	( SELECT TRIM(CORP_HIER_PRNT_CO_NBR) CO_NBR,TRIM(CORP_HIER_PRNT_CUST_NBR) PRNT_CUST_NBR, '19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM hive_CUST_SHIP_TO_src WHERE TRIM(CORP_HIER_PRNT_CUST_NBR) <>'')
	UNION 
	(SELECT TRIM(CORP_HIER_MSTR_CO_NBR) CO_NBR,TRIM(CORP_HIER_MSTR_CUST_NBR) PRNT_CUST_NBR, '19000101' AS SRC_CREAT_DT,
	's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM  FROM hive_CUST_SHIP_TO_src WHERE TRIM(CORP_HIER_MSTR_CUST_NBR) <>'')
	) CPM1 
	LEFT OUTER JOIN 
	(SELECT CO_NBR, PRNT_CUST_NBR, '19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM
	FROM rs_CUST_MSTR_PRNT_CUST_DIM_mstr A,rs_ORG_CO_DIM_mstr CO WHERE A.CO_SKEY=CO.CO_SKEY) CPM2 
	ON CPM1.CO_NBR=CPM2.CO_NBR AND CPM1.PRNT_CUST_NBR=CPM2.PRNT_CUST_NBR WHERE CPM2.CO_NBR IS NULL AND CPM2.PRNT_CUST_NBR IS NULL
	"""

vndr_co_vndr_ri_query = """
SELECT CSTD1.CO_NBR AS CO_NBR,CSTD1.VNDR_NBR AS VNDR_NBR,
'' AS VNDR_STS_ID, '99991231' AS VNDR_STS_EFF_DT, '' AS MSTR_VNDR_NBR, '' AS ALT_VNDR_NBR, '' AS PERM_VNDR_NBR, '' AS CRTF_OF_INS_IND, '99991231' AS INS_CRTF_EXPIR_DT, '' AS INS_CARR_ID, '' AS INS_CARR_2_ID, '' AS INS_CARR_3_ID, '' AS BNK_NM, '' AS BNK_ACCT_NBR, 0 AS TLRD_VAR_PCT, 0 AS TLRD_PCT_OF_VAR_NBR, 0 AS INS_CVR_VAL, '' AS ADD_INS_IND, '99991231' AS VNDR_CNCL_DT, '' AS BK_IND, '' AS VNDR_RPT_CATGY_CD, 0 AS APRV_CHK_AMT, '' AS PART_PAY_IND, '' AS DROP_SHIP_VNDR_IND, '' AS INTRCO_BIL_IND, '' AS INCL_OFF_INVC_IN_CSH_DSCNT_IND, '' AS INS_CRTF_NBR, 0 AS AP_ROL_DAY_NBR, '' AS VNDR_PAY_IND, '' AS MISC_ALLW_AND_CHRG_IND, '' AS PCKUP_ALLW_IND, '99991231' AS INS_CRTF_EXPIR_2_DT, 0 AS VNDR_BAL_SUM_TYP_CD, 0 AS MAIL_DAY_NBR, 0 AS MAX_INVC_AMT, '' AS VNDR_PO_ID, '' AS EMPLE_RHT_ADJ_CD, '' AS PO_REQ_IND, '' AS INVC_NBR_REQ_IND, '' AS CHK_RTE_CD, '' AS LITG_IND, '' AS DFLT_JOB_CD, '' AS RSTRC_TO_CO_GRP_NBR, '' AS DFLT_1099_CD, '' AS VNDR_FCT, 0 AS CRTCL_LVL_VAL, '' AS USE_TAX_AUTH_ID, '' AS VAL_ADD_TAX_AUTH_ID, '' AS PAY_APRV_CD, '' AS STD_DSTRB_CD, 0 AS IATA_NBR, '' AS VNDR_USER_FLD1_TXT, '' AS HLD_VNDR_IND, '' AS HLD_VOUCH_IND, '' AS SEP_CHK_IND, 0 AS PAY_DLAY_DAY_NBR, '' AS VNDR_FED_TAX_ID, '' AS VNDR_HOM_CURR_ID, '' AS DUP_PGM_ID, '' AS EDT_FIRST_COMBO_IND, '' AS EDT_SEC_COMBO_IND, '' AS EDT_THIRD_COMBO_IND, '99991231' AS EFF_DT, '99991231' AS HLD_HRMLS_EXPIR_DT, '' AS AP_ID, '' AS NAT_ACCT_NM, '' AS VNDR_AGR_CD, '99991231' AS MNR_OWN_EXPIR_DT, '99991231' AS AFFIRMATIVE_ACT_EXPIR_DT, '' AS TEMP_VNDR_IND, '' AS PREV_STS_ID, '' AS DFLT_ACCT_NM, '' AS AP_SORT_KEY_CD, '' AS RSTRC_TO_CO_NBR, '' AS DFLT_TERM_CD, '' AS ACT_VNDR_IND, '' AS SEP_REMIT_IND, 0 AS AVG_DAY_TO_CLR_BNK_NBR, 0 AS TOT_CLR_DOL_AMT, 0 AS TOT_CHKS_CLR_NBR, 0 AS TOT_DAY_TO_CLR_NBR, '' AS CLCT_CD, '' AS VNDR_RSTRC_IND, '' AS VNDR_CLSS_ID, '' AS SRVC_RTNG_ID, '' AS ALT_PAY_CD, '' AS HLD_HRMLS_ID, '' AS BNK_ID, '' AS PAY_CALC_CD, '' AS PAY_INFO_TERM_CHG_RSN_CD, '19000101' AS SRC_CREAT_DT, 0 AS SRC_CREAT_TM, '99991231' AS SRC_MOD_DT, 0 AS SRC_MOD_TM, CURRENT_TIMESTAMP AS INSRT_DTTM, CURRENT_TIMESTAMP AS UPDT_DTTM, 'ERR' AS SRC_SYS_CD, '' AS SESS_NM, 'N' AS PROC_STS_CD    
FROM( SELECT TRIM(VNDR_NBR) VNDR_NBR, TRIM(CO_NBR) CO_NBR,'19000101' AS SRC_CREAT_DT, 's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM hive_CUST_SHIP_TO_src WHERE TRIM(VNDR_NBR) <> '') CSTD1 
LEFT OUTER JOIN 
(SELECT VNDR_NBR, CO_NBR, '19000101' AS SRC_CREAT_DT, 's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM rs_VNDR_CO_VNDR_mstr A,rs_VNDR_DIM_mstr B,rs_ORG_CO_DIM_mstr C WHERE A.VNDR_SKEY = B.VNDR_SKEY AND A.CO_SKEY = C.CO_SKEY AND A.CURR_REC_IND='Y' ) CSTD2 
ON CSTD1.VNDR_NBR=CSTD2.VNDR_NBR AND CSTD1.CO_NBR=CSTD2.CO_NBR WHERE CSTD2.VNDR_NBR IS NULL AND CSTD2.CO_NBR IS NULL  
"""
	
vndr_co_vndr_ship_from_ri_query = """
	SELECT VCV1.VNDR_NBR, VCV1.CO_NBR,VCV1.VNDR_SHIP_PT_NBR,VCV1.SRC_CREAT_DT, VCV1.SESS_NM  
	FROM 
	(SELECT TRIM(VNDR_NBR) VNDR_NBR, TRIM(CO_NBR) CO_NBR,VNDR_SHIP_PT_NBR, '19000101' AS SRC_CREAT_DT,
	's_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM hive_CUST_SHIP_TO_src WHERE  TRIM(VNDR_NBR) <> '' AND VNDR_SHIP_PT_NBR <> 0 ) VCV1
	LEFT OUTER JOIN 
	(SELECT VNDR_NBR,CO_NBR,VNDR_SHIP_PT_NBR,'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM rs_VNDR_CO_VNDR_SHIP_FROM_mstr A,rs_VNDR_DIM_mstr B,rs_ORG_CO_DIM_mstr C,rs_VNDR_SHIP_FROM_DIM_mstr D WHERE A.VNDR_SKEY = B.VNDR_SKEY AND A.CO_SKEY = C.CO_SKEY AND A.VNDR_SHIP_FROM_SKEY = D.VNDR_SHIP_FROM_SKEY AND A.CURR_REC_IND='Y' AND D.CURR_REC_IND='Y') VCV2 
	ON VCV1.VNDR_NBR=VCV2.VNDR_NBR AND VCV1.CO_NBR=VCV2.CO_NBR AND VCV1.VNDR_SHIP_PT_NBR=VCV2.VNDR_SHIP_PT_NBR WHERE VCV2.VNDR_NBR IS NULL 
	AND VCV2.CO_NBR IS NULL AND VCV2.VNDR_SHIP_PT_NBR IS NULL 
	"""
	
org_enty_dtl_ri_query= """
	SELECT OS1.CO_NBR,OS1.ENTY_ID,OS1.ORG_LVL_NM,OS1.ORG_NM, OS1.SRC_CREAT_DT,OS1.SESS_NM 
	FROM 
	(SELECT TRIM(CO_NBR) CO_NBR,TRIM(TERR_CD) ENTY_ID,'TERR' ORG_LVL_NM,'SALES' ORG_NM,'19000101' AS SRC_CREAT_DT,'s_m_LNDToEDW_CUST_SHIP_TO_DIM' SESS_NM FROM hive_CUST_SHIP_TO_src WHERE TRIM(TERR_CD) <> '') OS1 
	LEFT OUTER JOIN 
	(SELECT CO_NBR,TERR_CD ENTY_ID,'TERR','SALES','19000101' AS SRC_CREAT_DT, 's_m_LNDToEDW_CUST_SHIP_TO_DIM' 
	FROM rs_ORG_SALE_HIER_REL_mstr A inner join rs_ORG_CO_DIM_mstr B ON A.CO_SKEY = B.CO_SKEY AND A.CURR_REC_IND='Y') OS2
	ON OS1.CO_NBR=OS2.CO_NBR AND OS1.ENTY_ID=OS2.ENTY_ID WHERE OS2.CO_NBR IS NULL AND OS2.ENTY_ID IS NULL
	"""

defalut_columns_org_enty_dtl__ri_query= """
	select CO_NBR,ENTY_ID,ORG_LVL_NM,ORG_NM,SRC_CREAT_DT,'' as enty_prnt_id,'' as enty_desc,'' as emple_nbr,'' as org_lvl_prnt_nm,'' as mdl_id,'' as 
	sts_id,'' as chg_flg,'' as user_id,'' as lptp_user_ind,0 as src_mod_dt,0 as src_creat_tm,0 as src_mod_tm,current_timestamp as 
	insrt_dttm,current_timestamp as updt_dttm,'ERR' as src_sys_cd,'cust_ship_to_s3_to_edw.py' as sess_nm,'N' as proc_sts_cd from org_enty_dtl_insert
	"""	

################################################ TRANSFORMATION QUERIES ##############################################
cust_ship_to_int_query="""SELECT *,
CASE WHEN 
VNDR_SKEY IS NULL OR 
vndr_ship_pt_skey IS NULL OR 
BIL_TO_SKEY IS NULL OR 
CO_SKEY IS NULL OR  
CORP_HIER_PRNT_CUST_SKEY IS NULL OR  
CORP_HIER_MSTR_CUST_SKEY IS NULL
THEN 'FILTER' ELSE 'PROCESS' END AS PROC_FLAG
FROM (
SELECT CUST_SHIP_TO_INTERMEDIATE.*,
CASE WHEN (CAST(var_PRFL_CREAT_DT AS DATE) IS NULL AND  PRFL_CREAT_DT <> 0) OR PRFL_CREAT_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_PRFL_CREAT_DT AS DATE) END AS out_PRFL_CREAT_DT,
CASE WHEN (CAST(var_STOP_DT AS DATE) IS NULL AND  STOP_DT <> 0) OR STOP_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_STOP_DT AS DATE) END AS out_STOP_DT,
CASE WHEN (CAST(var_ACCT_OPEN_DT AS DATE) IS NULL AND  ACCT_OPEN_DT <> 0) OR ACCT_OPEN_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_ACCT_OPEN_DT AS DATE)  END AS out_ACCT_OPEN_DT,
CASE WHEN (CAST(var_ACCT_CLOS_DT AS DATE) IS NULL AND  ACCT_CLOS_DT <> 0) OR ACCT_CLOS_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_ACCT_CLOS_DT AS DATE) 
END AS out_ACCT_CLOS_DT,
CASE WHEN (CAST(var_FIRST_INVC_DT AS DATE) IS NULL AND  FIRST_INVC_DT <> 0) OR FIRST_INVC_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_FIRST_INVC_DT AS DATE) END AS out_FIRST_INVC_DT,
CASE WHEN (CAST(var_LST_INVC_DT AS DATE) IS NULL AND  LST_INVC_DT <> 0) OR LST_INVC_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_LST_INVC_DT AS DATE) END AS out_LST_INVC_DT,
CASE WHEN (CAST(var_LST_CSH_DT AS DATE) IS NULL AND  LST_CSH_DT <> 0) OR LST_CSH_DT=0 THEN CAST('9999-12-31' AS DATE) ELSE CAST(var_LST_CSH_DT AS DATE) END AS out_LST_CSH_DT,
CASE WHEN CAST(var_SRC_CREAT_DT AS DATE) IS NULL THEN CAST('1900-01-01' AS DATE) ELSE CAST(var_SRC_CREAT_DT AS DATE) END AS out_SRC_CREAT_DT,

CASE WHEN 
(CAST(var_PRFL_CREAT_DT AS DATE) IS NULL  AND  PRFL_CREAT_DT <> 0) OR 
(CAST(var_STOP_DT AS DATE) IS NULL  AND  STOP_DT <> 0) OR 
(CAST(var_ACCT_OPEN_DT AS DATE) IS NULL  AND  ACCT_OPEN_DT <> 0) OR 
(CAST(var_ACCT_CLOS_DT AS DATE) IS NULL  AND  ACCT_CLOS_DT <> 0) OR 
(CAST(var_FIRST_INVC_DT AS DATE) IS NULL  AND  FIRST_INVC_DT <> 0) OR 
(CAST(var_LST_INVC_DT AS DATE) IS NULL  AND  LST_INVC_DT <> 0) OR
(CAST(var_LST_CSH_DT AS DATE) IS NULL  AND  LST_CSH_DT <> 0) OR
(CAST(var_SRC_CREAT_DT AS DATE) IS NULL) THEN 'Y' ELSE 'N' END AS out_DATE_CHECK_FLAG,

CASE WHEN CUST_SHIP_TO_INTERMEDIATE.corp_hier_prnt_cust_nbr='' OR rs_cust_mstr_prnt_cust_dim_mstr.prnt_cust_skey is NULL 
THEN -100 else rs_cust_mstr_prnt_cust_dim_mstr.prnt_cust_skey end as corp_hier_prnt_cust_skey, 

case when CUST_SHIP_TO_INTERMEDIATE.corp_hier_mstr_cust_nbr='' or CMP.prnt_cust_skey is null 
then -100 else CMP.prnt_cust_skey end as corp_hier_mstr_cust_skey,

case when var_SYSTEM_SIZE = '' then npd_upd_sysco_unique.SYSTEM_SIZE else var_SYSTEM_SIZE end as SYSTEM_SIZE,
case when var_NPD_SYSCO_SEGMENTATION = '' then npd_upd_sysco_unique.NPD_SYSCO_SEGMENTATION else var_NPD_SYSCO_SEGMENTATION end as NPD_SYSCO_SEGMENTATION

FROM ( SELECT 
TRIM(SRC.CUST_NBR) AS CUST_NBR,
TRIM(SRC.CO_NBR) AS CO_NBR,
TRIM(SRC.VNDR_NBR) AS VNDR_NBR,
TRIM(SRC.CORP_HIER_PRNT_CO_NBR) AS CORP_HIER_PRNT_CO_NBR,
TRIM(SRC.CORP_HIER_PRNT_CUST_NBR) AS CORP_HIER_PRNT_CUST_NBR,
SRC.VNDR_SHIP_PT_NBR,
TRIM(SRC.BIL_TO_NBR) AS BIL_TO_NBR,
TRIM(SRC.fed_tax_payr_id) as fed_tax_payr_id,
TRIM(SRC.CORP_HIER_MSTR_CO_NBR) AS CORP_HIER_MSTR_CO_NBR,
TRIM(SRC.CORP_HIER_MSTR_CUST_NBR) AS CORP_HIER_MSTR_CUST_NBR,
TRIM(SRC.slspn_cd) as slspn_cd,
TRIM(SRC.cust_nm) as cust_nm,
TRIM(SRC.addr_line_1_txt) as addr_line_1_txt,
TRIM(SRC.addr_line_2_txt) as addr_line_2_txt,
TRIM(SRC.addr_line_3_txt) as addr_line_3_txt,
TRIM(SRC.cty_nm) as cty_nm,
TRIM(SRC.stt_cd) as stt_cd,
TRIM(SRC.cnty_nm) as cnty_nm,
TRIM(SRC.zip_cd) as zip_cd,
TRIM(SRC.cntry_cd) as cntry_cd,
TRIM(SRC.cust_alias_nm) as cust_alias_nm,
TRIM(SRC.cust_catgy_cd) as cust_catgy_cd,
TRIM(SRC.maj_clss_cd) as maj_clss_cd,
TRIM(SRC.mnr_clss_cd) as mnr_clss_cd,
TRIM(substr(SRC.sort_nm,1,16)) as sort_nm,
TRIM(SRC.appl_sts_cd) as appl_sts_cd,
TRIM(SRC.one_tm_cust_ind) as one_tm_cust_ind,
TRIM(SRC.act_inac_ind) as act_inac_ind,
case when TRIM(SRC.PAY_TERM_PLCY_CD)='' and rs_cust_bil_to_dim_mstr.DFLT_PAY_TERM_PLCY_CD is not null then 
rs_cust_bil_to_dim_mstr.DFLT_PAY_TERM_PLCY_CD else SRC.PAY_TERM_PLCY_CD end as pay_term_plcy_cd,
TRIM(SRC.acct_grp_cd) as acct_grp_cd,
TRIM(SRC.age_plcy_cd) as age_plcy_cd,
TRIM(SRC.tel_nbr) as tel_nbr,
TRIM(SRC.fax_nbr) as fax_nbr,
TRIM(SRC.dlvr_cd) as dlvr_cd,
TRIM(SRC.ship_to_stor_nbr) as ship_to_stor_nbr,
TRIM(SRC.ordr_aprv_rqr_ind) as ordr_aprv_rqr_ind,
TRIM(SRC.acct_typ_cd) as acct_typ_cd,
TRIM(SRC.corp_typ_of_oper_cd) as corp_typ_of_oper_cd,
TRIM(SRC.cuisine_cd) as cuisine_cd,
SRC.prfl_creat_dt as prfl_creat_dt,
TRIM(SRC.dflt_sbst_typ_cd) as dflt_sbst_typ_cd,
TRIM(SRC.dflt_rstrc_typ_cd) as dflt_rstrc_typ_cd,
TRIM(SRC.frc_sbst_ind) as frc_sbst_ind,
TRIM(SRC.dept_ind) as dept_ind,
TRIM(SRC.part_fill_ind) as part_fill_ind,
TRIM(SRC.non_prft_ind) as non_prft_ind,
TRIM(SRC.misc_tax_xmpt_ind) as misc_tax_xmpt_ind,
TRIM(SRC.terr_cd) as terr_cd,
TRIM(SRC.immed_alloc_ind) as immed_alloc_ind,
TRIM(SRC.cust_ship_to_sts_id) as cust_ship_to_sts_id,
TRIM(SRC.ordr_pl_ind) as ordr_pl_ind,
TRIM(SRC.cust_typ_cd) as cust_typ_cd,
TRIM(SRC.cust_cmdty_cd) as cust_cmdty_cd,
TRIM(SRC.prev_sts_id) as prev_sts_id,
TRIM(SRC.pay_term_cd) as pay_term_cd,
TRIM(SRC.lcl_typ_of_oper_cd) as lcl_typ_of_oper_cd,
SRC.STOP_DT,
SRC.stop_cntr_val,
TRIM(SRC.prc_rule_nm) as prc_rule_nm,
TRIM(SRC.stop_cd) as stop_cd,
TRIM(SRC.terr_ovrd_ind) as terr_ovrd_ind,
TRIM(SRC.cust_enty_typ_cd) as cust_enty_typ_cd,
TRIM(SRC.cmdty_ind) as cmdty_ind,
TRIM(SRC.kosher_cust_ind) as kosher_cust_ind,
TRIM(SRC.prm_ship_to_nbr) as prm_ship_to_nbr,
TRIM(SRC.dlvr_dfclt_rtng_id) as dlvr_dfclt_rtng_id,
TRIM(SRC.prr_yr_rtng_cd) as prr_yr_rtng_cd,
TRIM(SRC.prr_mo_rtng_cd) as prr_mo_rtng_cd,
TRIM(SRC.lcl_cust_rtng_cd) as lcl_cust_rtng_cd,
TRIM(SRC.esysco_cust_ind) as esysco_cust_ind,
SRC.cust_crdt_lmt_bc_amt as cust_crdt_lmt_bc_amt,
SRC.unappl_csh_bal_bc_amt as unappl_csh_bal_bc_amt,
SRC.open_itm_bal_bc_amt as open_itm_bal_bc_amt,
SRC.open_itm_cnt as open_itm_cnt,
SRC.on_ordr_amt_std_ordr_bc_amt as on_ordr_amt_std_ordr_bc_amt,
SRC.on_ordr_amt_drop_ship_bc_amt as on_ordr_amt_drop_ship_bc_amt,
SRC.ACCT_OPEN_DT,
SRC.acct_clos_dt,
SRC.first_invc_dt,
SRC.lst_invc_dt,
SRC.lst_invc_amt_bc_amt as lst_invc_amt_bc_amt,
SRC.lst_csh_dt,
--cast(SRC.lst_csh_amt_bc_amt as int) as lst_csh_amt_bc_amt,
round(SRC.lst_csh_amt_bc_amt) as lst_csh_amt_bc_amt,
TRIM(SRC.ar_typ_cd) as ar_typ_cd,
TRIM(SRC.crdt_stop_aprv_pnd_ind) as crdt_stop_aprv_pnd_ind,
TRIM(SRC.tax_xmpt_ind) as tax_xmpt_ind,
SRC.lat_coord_val,
SRC.lon_coord_val,
TRIM(SRC.dir_of_lat_id) as dir_of_lat_id,
TRIM(SRC.dir_of_lon_id) as dir_of_lon_id,
TRIM(SRC.sale_lvl_id) as sale_lvl_id,
SRC.src_creat_dt,
SRC.src_creat_tm,
SRC.src_mod_dt,
SRC.src_mod_tm,
CURRENT_TIMESTAMP AS INSRT_DTTM, 
CURRENT_TIMESTAMP AS UPDT_DTTM,
CASE WHEN SRC.SRC_SYS_CD IS NULL OR SRC.SRC_SYS_CD = '' THEN 'ERR' ELSE SRC.SRC_SYS_CD END as src_sys_cd,
SRC.sess_nm,
SRC.proc_sts_cd,
TRIM(SRC.net_due_grace_day_cd) as net_due_grace_day_cd,
SRC.dscnt,
SRC.day_in_dscnt_prd,
SRC.day_in_net_due_prd,
TRIM(SRC.term_typ) as term_typ,
TRIM(SRC.pay_term_plcy_desc) as pay_term_plcy_desc,

CASE WHEN rs_org_co_dim_mstr.SAP_IND='Y' AND LENGTH(SRC.CUST_NBR)=10 AND SRC.SAP_IND=0 THEN '1' ELSE SRC.sap_ind END as sap_ind,

TRIM(SRC.rtlr_fein_nbr) as rtlr_fein_nbr,
TRIM(SRC.cust_beer_prmt_nbr) as cust_beer_prmt_nbr,
 
CASE WHEN S2S.FROM_CUST_NBR IS NULL THEN (
	CASE WHEN CUST_XREF_SAP_REL.CUST_NBR IS NULL THEN (
		CASE WHEN rs_org_co_dim_mstr.SAP_IND='Y' THEN SRC.CUST_NBR ELSE '' END) 
	ELSE CUST_XREF_SAP_REL.CUST_NBR END) 
ELSE S2S.FROM_CUST_NBR END AS SAP_CUST_NBR,

CASE WHEN S2S.FROM_CUST_NBR IS NULL THEN (
	CASE WHEN CUST_XREF_SAP_REL.CUST_NBR IS NULL AND CUST_XREF_SAP_REL.CUST_ORIG_NM IS NULL THEN (
		CASE WHEN rs_org_co_dim_mstr.SAP_IND='Y' THEN SRC.CUST_NM ELSE '' END) 
	ELSE CUST_XREF_SAP_REL.CUST_ORIG_NM END)
ELSE '' END AS SAP_CUST_NM,
 
CASE WHEN S2S.FROM_CUST_NBR IS NULL THEN (
	CASE WHEN CUST_XREF_SAP_REL.CUST_ACCT_GRP_NM IS NULL THEN (
		CASE WHEN rs_org_co_dim_mstr.SAP_IND='Y' THEN 'TRADE' ELSE '' END)
	ELSE CUST_XREF_SAP_REL.CUST_ACCT_GRP_NM END)
ELSE '' END	AS SAP_ACCT_GRP_NM,

FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(SRC.prfl_creat_dt AS STRING),'yyyyMMdd'),'yyyy-MM-dd') AS var_PRFL_CREAT_DT,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(SRC.STOP_DT AS STRING),'yyyyMMdd'),'yyyy-MM-dd') AS var_STOP_DT,
'' as cust_skey,
CAST('1900-01-01' AS DATE) as cust_ship_to_rec_eff_dt,
CAST('9999-12-31' AS DATE) as cust_ship_to_rec_trm_dt,
'Y' as curr_rec_ind,
rs_org_co_dim_mstr.co_skey as co_skey,
rs_vndr_dim_mstr.vndr_skey as vndr_skey,
CASE WHEN rs_vndr_dim_mstr.vndr_skey = -100 OR SRC.vndr_ship_pt_nbr=0 THEN -100 ELSE rs_vndr_ship_from_dim_mstr.vndr_ship_from_skey END as vndr_ship_pt_skey,
CASE WHEN TRIM(SRC.bil_to_nbr)='' THEN -100 ELSE rs_cust_bil_to_dim_mstr.bil_to_skey END as bil_to_skey,

CASE WHEN rs_org_co_dim_mstr.CO_TYP_IND='F' THEN 'NA' ELSE case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dept_id end END as dept_id,

CASE WHEN rs_org_co_dim_mstr.CO_TYP_IND='F' THEN 'NA' ELSE case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dept_nm end END as dept_nm,

case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dept_emple_id end as dept_emple_id,

CASE WHEN rs_org_co_dim_mstr.CO_TYP_IND='F' THEN 'NA1' ELSE case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.rgn_id end END as rgn_id,

CASE WHEN rs_org_co_dim_mstr.CO_TYP_IND='F' THEN 'NA1' ELSE case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.rgn_nm end END as rgn_nm,

case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.rgn_emple_id end as rgn_emple_id,
case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dist_id end as dist_id,
case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dist_nm end as dist_nm,
case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.dist_emple_id end as dist_emple_id,
case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.terr_nm end as terr_nm,
case when rs_org_sale_hier_rel_mstr.TERR_CD is null or trim(rs_org_sale_hier_rel_mstr.TERR_CD) = '' then 'UNKNOWN' else rs_org_sale_hier_rel_mstr.terr_emple_id end as terr_emple_id,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.ACCT_OPEN_DT,8,0) AS STRING),'MMddyyyy'),'yyyy-MM-dd') AS var_ACCT_OPEN_DT,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.acct_clos_dt,8,0) AS STRING),'MMddyyyy'),'yyyy-MM-dd') AS var_ACCT_CLOS_DT,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.first_invc_dt,8,0) AS STRING),'MMddyyyy'),'yyyy-MM-dd') AS var_FIRST_INVC_DT,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.lst_invc_dt,8,0) AS STRING),'MMddyyyy'),'yyyy-MM-dd') AS var_LST_INVC_DT,
FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.lst_csh_dt,8,0) AS STRING),'MMddyyyy'),'yyyy-MM-dd') AS var_LST_CSH_DT,

case when (rs_cust_misc_mstr.cust_stor_nbr is null or trim(rs_cust_misc_mstr.cust_stor_nbr)='' or rs_cust_stor_rqr_ind_check_mstr.cust_nbr is null) then CONCAT(SRC.CO_NBR,SRC.prm_ship_to_nbr) else rs_cust_misc_mstr.cust_stor_nbr end as corp_ship_to_stor_nbr,

FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(LPAD(SRC.src_creat_dt,8,0) AS STRING),'yyyyMMdd'),'yyyy-MM-dd') AS var_SRC_CREAT_DT,
'' as TYP_2_OPER_CD,

case when rs_npd_upd_sysco_mstr.cust_nbr is null then '' else rs_npd_upd_sysco_mstr.SYSTEM_SIZE end as var_SYSTEM_SIZE,
case when rs_npd_upd_sysco_mstr.cust_nbr is null then '' else rs_npd_upd_sysco_mstr.NPD_SYSCO_SEGMENTATION end as var_NPD_SYSCO_SEGMENTATION,

CASE WHEN LTRIM(RTRIM(SRC.CUST_NBR))='' or LTRIM(RTRIM(SRC.CO_NBR))='' THEN 'Y' ELSE 'N' END AS out_PK_CHECK_FLAG,
--rs_cust_misc_mstr.REC_CNT,
CASE WHEN rs_cust_misc_mstr.REC_CNT IS NULL THEN 0 ELSE rs_cust_misc_mstr.REC_CNT END AS REC_CNT,

case when och.co_skey is null then (case when TRIM(SRC.corp_hier_prnt_co_nbr)='' then -100 else -200 end ) else och.co_skey end as sub_1_co_skey,
case when ocd1.co_skey is null then (case when TRIM(SRC.corp_hier_mstr_co_nbr)='' then -100 else -200 end ) else ocd1.co_skey end as sub_2_co_skey

from hive_cust_ship_to_src SRC 

left outer join rs_org_co_dim_mstr on TRIM(SRC.co_nbr)=TRIM(rs_org_co_dim_mstr.co_nbr) 

left outer join rs_org_co_dim_mstr och on TRIM(SRC.corp_hier_prnt_co_nbr)=TRIM(och.co_nbr) 
left outer join rs_org_co_dim_mstr ocd1 on TRIM(SRC.corp_hier_mstr_co_nbr)=TRIM(ocd1.co_nbr) 

left outer join rs_vndr_dim_mstr on TRIM(SRC.vndr_nbr)=TRIM(rs_vndr_dim_mstr.vndr_nbr) 
left outer join rs_vndr_ship_from_dim_mstr on rs_vndr_dim_mstr.vndr_skey=rs_vndr_ship_from_dim_mstr.vndr_skey and  rs_vndr_ship_from_dim_mstr.vndr_ship_pt_nbr=SRC.vndr_ship_pt_nbr 
left outer join rs_cust_bil_to_dim_mstr on TRIM(SRC.bil_to_nbr)=TRIM(rs_cust_bil_to_dim_mstr.bil_to_nbr) and   rs_org_co_dim_mstr.co_skey=rs_cust_bil_to_dim_mstr.co_skey 

left outer join rs_cust_misc_mstr on TRIM(rs_cust_misc_mstr.CO_NBR)=TRIM(SRC.CO_NBR) and TRIM(rs_cust_misc_mstr.CUST_NBR)=TRIM(SRC.CUST_NBR)  
left outer join rs_cust_stor_rqr_ind_check_mstr on rs_org_co_dim_mstr.co_skey=rs_cust_stor_rqr_ind_check_mstr.co_skey and   TRIM(SRC.cust_nbr)=TRIM(rs_cust_stor_rqr_ind_check_mstr.cust_nbr) 
left outer join rs_org_sale_hier_rel_mstr on rs_org_co_dim_mstr.co_skey=rs_org_sale_hier_rel_mstr.co_skey and  TRIM(SRC.terr_cd)=TRIM(rs_org_sale_hier_rel_mstr.terr_cd) 

left outer join rs_npd_upd_sysco_mstr on rs_org_co_dim_mstr.co_skey=rs_npd_upd_sysco_mstr.CO_SKEY and TRIM(SRC.cust_nbr)=TRIM(rs_npd_upd_sysco_mstr.cust_nbr) and upper(trim(rs_npd_upd_sysco_mstr.name))=upper(trim(SRC.CUST_NM))

LEFT OUTER JOIN rs_CUST_XREF_SAP_REL_mstr CUST_XREF_SAP_REL ON TRIM(SRC.CUST_NBR)=TRIM(CUST_XREF_SAP_REL.LGCY_CUST_NBR) AND rs_org_co_dim_mstr.CO_SKEY=CUST_XREF_SAP_REL.CO_SKEY
AND TRIM(UPPER(CUST_XREF_SAP_REL.CUST_ACCT_GRP_NM)) NOT IN ('PAYER','PLANT') AND TRIM(UPPER(CUST_XREF_SAP_REL.CUST_TYP_CD))='TRADE'
AND SRC.SRC_SYS_CD NOT IN ('ERR','BT')

LEFT OUTER JOIN rs_SALE_BUS_TRNSF_S2S_HIST_mstr S2S ON TRIM(SRC.CUST_NBR)=S2S.TO_CUST_NBR AND rs_org_co_dim_mstr.CO_SKEY=S2S.CO_SKEY 
AND S2S.TRNSF_TYP_CD='SAPToSUS'

) CUST_SHIP_TO_INTERMEDIATE

left outer join rs_cust_mstr_prnt_cust_dim_mstr on TRIM(rs_cust_mstr_prnt_cust_dim_mstr.prnt_cust_nbr)=TRIM(CUST_SHIP_TO_INTERMEDIATE.corp_hier_prnt_cust_nbr) and rs_cust_mstr_prnt_cust_dim_mstr.co_skey=CUST_SHIP_TO_INTERMEDIATE.sub_1_co_skey 

left outer join rs_cust_mstr_prnt_cust_dim_mstr CMP on TRIM(CMP.prnt_cust_nbr)=TRIM(CUST_SHIP_TO_INTERMEDIATE.corp_hier_mstr_cust_nbr) and  CMP.co_skey=CUST_SHIP_TO_INTERMEDIATE.sub_2_co_skey 

left outer join npd_upd_sysco_unique on npd_upd_sysco_unique.co_skey = CUST_SHIP_TO_INTERMEDIATE.co_skey and trim(npd_upd_sysco_unique.cust_nbr) = trim(CUST_SHIP_TO_INTERMEDIATE.cust_nbr)

) A"""

cust_ship_to_int_ri_query="""SELECT 
cust_nbr,
CO_NBR,
VNDR_NBR,
CORP_HIER_PRNT_CO_NBR,
CORP_HIER_PRNT_CUST_NBR,
VNDR_SHIP_PT_NBR,
BIL_TO_NBR,
fed_tax_payr_id,
CORP_HIER_MSTR_CO_NBR,
CORP_HIER_MSTR_CUST_NBR,
slspn_cd,
cust_nm,
addr_line_1_txt,
addr_line_2_txt,
addr_line_3_txt,
cty_nm,stt_cd,
cnty_nm,zip_cd,
cntry_cd,
cust_alias_nm,
cust_catgy_cd,
maj_clss_cd,
mnr_clss_cd,
sort_nm,
appl_sts_cd,
one_tm_cust_ind,
act_inac_ind,
pay_term_plcy_cd,
acct_grp_cd,
age_plcy_cd,
tel_nbr,
fax_nbr,
dlvr_cd,
ship_to_stor_nbr,
ordr_aprv_rqr_ind,
acct_typ_cd,
corp_typ_of_oper_cd,
cuisine_cd,
prfl_creat_dt,
dflt_sbst_typ_cd,
dflt_rstrc_typ_cd,
frc_sbst_ind,
dept_ind,
part_fill_ind,
non_prft_ind,
misc_tax_xmpt_ind,
terr_cd,
immed_alloc_ind,
cust_ship_to_sts_id,
ordr_pl_ind,
cust_typ_cd,
cust_cmdty_cd,
prev_sts_id,
pay_term_cd,
lcl_typ_of_oper_cd,
STOP_DT,
stop_cntr_val,
prc_rule_nm,
stop_cd,
terr_ovrd_ind,
cust_enty_typ_cd,
cmdty_ind,
kosher_cust_ind,
prm_ship_to_nbr,
dlvr_dfclt_rtng_id,
prr_yr_rtng_cd,
prr_mo_rtng_cd,
lcl_cust_rtng_cd,
esysco_cust_ind,
cust_crdt_lmt_bc_amt,
unappl_csh_bal_bc_amt,
open_itm_bal_bc_amt,
open_itm_cnt,
on_ordr_amt_std_ordr_bc_amt,
on_ordr_amt_drop_ship_bc_amt,
ACCT_OPEN_DT,
acct_clos_dt,
first_invc_dt,
lst_invc_dt,
lst_invc_amt_bc_amt,
lst_csh_dt,
lst_csh_amt_bc_amt,
ar_typ_cd,
crdt_stop_aprv_pnd_ind,
tax_xmpt_ind,
lat_coord_val,
lon_coord_val,
dir_of_lat_id,
dir_of_lon_id,
sale_lvl_id,
src_creat_dt,
src_creat_tm,
src_mod_dt,
src_mod_tm,
CURRENT_TIMESTAMP AS INSRT_DTTM, 
CURRENT_TIMESTAMP AS UPDT_DTTM,
src_sys_cd,
sess_nm,
proc_sts_cd,
net_due_grace_day_cd,
dscnt,
day_in_dscnt_prd,
day_in_net_due_prd,
term_typ,
pay_term_plcy_desc,
sap_ind as sap_ind,
rtlr_fein_nbr,
cust_beer_prmt_nbr  
FROM CUST_SHIP_TO_INT WHERE PROC_FLAG='FILTER'
"""

cust_ship_to_int_process_query="""
SELECT * FROM CUST_SHIP_TO_INT_MAIN WHERE PROC_FLAG='PROCESS'
"""

################################################ Error/History Update QUERIES ##########################################################################

load_err_fact_query="""
SELECT CO_NBR AS CO_NBR,
'CUST_SHIP_TO_DIM' AS SRC_TBL_NM,
CONCAT('CO_NBR - ',LTRIM(RTRIM(CO_NBR)),',CUST_NBR(CUCUNO) - ',LTRIM(RTRIM(CUST_NBR)))AS SRC_TBL_PK_FLD_NM_VAL,
'CUST_SHIP_TO_DIM' AS TGT_TBL_NM,
CONCAT('CO_NBR - ', LTRIM(RTRIM(CO_NBR)), ',CUST_NBR - ', LTRIM(RTRIM(CUST_NBR)))AS TGT_TBL_PK_FLD_NM_VAL,
CASE WHEN out_DATE_CHECK_FLAG='Y' THEN
CONCAT(
CASE WHEN CAST(var_PRFL_CREAT_DT AS DATE) IS NULL  AND  PRFL_CREAT_DT <> 0 THEN concat('PRFL_CREAT_DT - ', PRFL_CREAT_DT) ELSE ' ' END,
CASE WHEN CAST(var_STOP_DT AS DATE) IS NULL  AND  STOP_DT <> 0 THEN concat('STOP_DT - ', STOP_DT) ELSE ' ' END,
CASE WHEN CAST(var_ACCT_OPEN_DT AS DATE) IS NULL  AND  ACCT_OPEN_DT <> 0 THEN concat('ACCT_OPEN_DT - ',ACCT_OPEN_DT) ELSE ' ' END,
CASE WHEN CAST(var_ACCT_CLOS_DT AS DATE) IS NULL  AND  ACCT_CLOS_DT <> 0 THEN concat('ACCT_CLOS_DT - ', ACCT_CLOS_DT) ELSE ' ' END,
CASE WHEN CAST(var_FIRST_INVC_DT AS DATE) IS NULL  AND  FIRST_INVC_DT <> 0 THEN concat('FIRST_INVC_DT - ', FIRST_INVC_DT) ELSE ' ' END,
CASE WHEN CAST(var_LST_CSH_DT AS DATE) IS NULL  AND  LST_CSH_DT <> 0 THEN concat('LST_CSH_DT - ', LST_CSH_DT) ELSE ' ' END,
CASE WHEN CAST(var_SRC_CREAT_DT AS DATE) IS NULL  AND  SRC_CREAT_DT <> 0 THEN concat('SRC_CREAT_DT - ', SRC_CREAT_DT) ELSE ' ' END,
CASE WHEN CAST(var_LST_INVC_DT AS DATE) IS NULL  AND  LST_INVC_DT <> 0 THEN concat('LST_INVC_DT - ', LST_INVC_DT) ELSE ' ' END)
ELSE
CONCAT(
CASE WHEN LTRIM(RTRIM(CUST_NBR))='' THEN CONCAT('CUST_NBR',' - ',CUST_NBR) ELSE ' ' END,
CASE WHEN LTRIM(RTRIM(CO_NBR))='' THEN CONCAT('CO_NBR',' - ',CO_NBR) ELSE ' ' END) END AS SRC_FLD_NM_VAL,

CASE WHEN out_DATE_CHECK_FLAG='Y' THEN
CONCAT( 
CASE WHEN CAST(var_PRFL_CREAT_DT AS DATE) IS NULL THEN 'PRFL_CREAT_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_STOP_DT AS DATE) IS NULL THEN 'STOP_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_ACCT_OPEN_DT AS DATE) IS NULL THEN 'ACCT_OPEN_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_ACCT_CLOS_DT AS DATE) IS NULL THEN 'ACCT_CLOS_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_FIRST_INVC_DT AS DATE) IS NULL THEN 'FIRST_INVC_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_SRC_CREAT_DT AS DATE) IS NULL THEN 'SRC_CREAT_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_LST_INVC_DT AS DATE) IS NULL THEN 'LST_INVC_DT - 9999-12-31'  ELSE ' ' END,
CASE WHEN CAST(var_LST_CSH_DT AS DATE) IS NULL THEN 'LST_CSH_DT - 9999-12-31'  ELSE ' ' END) ELSE 'NA' END AS TGT_FLD_NM_VAL,
'NA' AS LOOK_TBL_NM,
'NA' AS LOOK_FLD_NM,
'O' AS ERR_STS_CD,
3 AS ERR_CD,
SRC_SYS_CD AS SRC_SYS_CD,
CURRENT_TIMESTAMP AS INSRT_DTTM, 
CURRENT_TIMESTAMP AS UPDT_DTTM
FROM CUST_SHIP_TO_INT WHERE (out_PK_CHECK_FLAG='Y' OR out_DATE_CHECK_FLAG='Y') AND PROC_FLAG='PROCESS'"""


#SQL to generate data to insert it into Redshift - LOAD_HIST_FACT table..
load_hist_fact_query="""
	SELECT DISTINCT
	5 AS LOAD_ID,
	concat('s_m_LNDToEDW_CUST_SHIP_TO_DIM_',CO_NBR) AS SESS_NM,  
	'{}' AS SESS_STRT_TM,
	CURRENT_TIMESTAMP AS SESS_END_TM, 
	0 AS EXPT_CNT, 
	0 AS INSRT_CNT, 
	0 AS UPDT_CNT, 
	'CUST_SHIP_TO_DIMT' AS TGT_TBL_NM, 
	0 AS SRC_READ_CNT, 
	0 AS REJ_CNT, 
	'C' AS ETL_STS, 
	CURRENT_TIMESTAMP AS INSRT_DTTM, 
	CURRENT_TIMESTAMP AS UPDT_DTTM
	FROM rs_ORG_CO_DIM_mstr where (CO_NBR in ({}) OR '000' IN ({}))"""	


############################################      MAJOR/MINOR UPDATE QUERIES      #################################################################

cust_ship_to_scd_query = """
	SELECT *,
	CASE WHEN CNT_KEY=1 THEN 'Y' ELSE 'N' END INS,
	CASE WHEN CNT_KEY>1 AND CNT_KEY<>CNT_SCD2 THEN 'Y' ELSE 'N' END MAJ,
	CASE WHEN CNT_KEY>1 AND CNT_KEY<>CNT_SCD1 THEN 'Y' ELSE 'N' END MNR,
	CASE WHEN CUST_SKEY_1 IS NULL THEN SKEY ELSE CUST_SKEY_1 END AS CUST_SKEY
	FROM (
	SELECT *, 
	COUNT(1) OVER(PARTITION BY CO_SKEY, CUST_NBR) CNT_KEY,
	
	COUNT(1) OVER(PARTITION BY CO_SKEY, CUST_NBR, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, TRIM(SLSPN_CD), TRIM(CUST_ALIAS_NM), TRIM(ACT_INAC_IND), TRIM(PAY_TERM_PLCY_CD), TRIM(ACCT_TYP_CD), TRIM(TERR_CD), TRIM(CUST_SHIP_TO_STS_ID), TRIM(CUST_TYP_CD), TRIM(PAY_TERM_CD), TRIM(PRC_RULE_NM), TRIM(STOP_CD), TRIM(PRM_SHIP_TO_NBR), TRIM(PRR_YR_RTNG_CD), TRIM(PRR_MO_RTNG_CD), TRIM(LCL_CUST_RTNG_CD), TRIM(SRC_SYS_CD), TRIM(LCL_TYP_OF_OPER_CD), TRIM(CORP_TYP_OF_OPER_CD)) CNT_SCD2,
	
	COUNT(1) OVER(PARTITION BY CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, TRIM(FED_TAX_PAYR_ID), TRIM(CUST_NM), TRIM(ADDR_LINE_1_TXT), TRIM(ADDR_LINE_3_TXT), TRIM(ADDR_LINE_2_TXT), TRIM(CTY_NM), TRIM(STT_CD), TRIM(CNTY_NM), TRIM(ZIP_CD), TRIM(CNTRY_CD), TRIM(CUST_CATGY_CD), TRIM(MAJ_CLSS_CD), TRIM(MNR_CLSS_CD), TRIM(SORT_NM), TRIM(APPL_STS_CD), TRIM(ONE_TM_CUST_IND), TRIM(ACCT_GRP_CD), TRIM(AGE_PLCY_CD), TRIM(TEL_NBR), TRIM(FAX_NBR), TRIM(DLVR_CD), TRIM(SHIP_TO_STOR_NBR), TRIM(ORDR_APRV_RQR_IND), TRIM(CUISINE_CD), PRFL_CREAT_DT, TRIM(DFLT_SBST_TYP_CD), TRIM(DFLT_RSTRC_TYP_CD), TRIM(FRC_SBST_IND), TRIM(DEPT_IND), TRIM(PART_FILL_IND), TRIM(NON_PRFT_IND), TRIM(MISC_TAX_XMPT_IND), TRIM(IMMED_ALLOC_IND), TRIM(ORDR_PL_IND), TRIM(CUST_CMDTY_CD), STOP_DT, TRIM(PREV_STS_ID), TRIM(STOP_CNTR_VAL), TRIM(TERR_OVRD_IND), TRIM(CUST_ENTY_TYP_CD), TRIM(CMDTY_IND), TRIM(KOSHER_CUST_IND), TRIM(DLVR_DFCLT_RTNG_ID), TRIM(ESYSCO_CUST_IND), CUST_CRDT_LMT_BC_AMT, TRIM(UNAPPL_CSH_BAL_BC_AMT), OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, ACCT_OPEN_DT, ACCT_CLOS_DT, FIRST_INVC_DT, LST_INVC_DT, LST_INVC_AMT_BC_AMT, LST_CSH_DT, LST_CSH_AMT_BC_AMT, TRIM(AR_TYP_CD), TRIM(CRDT_STOP_APRV_PND_IND), TRIM(TAX_XMPT_IND), LAT_COORD_VAL, LON_COORD_VAL, TRIM(DIR_OF_LAT_ID), TRIM(DIR_OF_LON_ID), TRIM(SALE_LVL_ID), TRIM(CUST_BEER_PRMT_NBR), TRIM(RTLR_FEIN_NBR), BIL_TO_SKEY, TRIM(CORP_SHIP_TO_STOR_NBR),TRIM(DEPT_ID), TRIM(DEPT_NM), TRIM(DEPT_EMPLE_ID), TRIM(RGN_ID), TRIM(RGN_NM), TRIM(RGN_EMPLE_ID), TRIM(DIST_ID), TRIM(DIST_NM), TRIM(DIST_EMPLE_ID), TRIM(TERR_NM), TRIM(TERR_EMPLE_ID)) CNT_SCD1,
	
	LEAD(SKEY , 1) OVER(PARTITION BY CO_SKEY, CUST_NBR ORDER BY CURR_REC_IND DESC) AS CUST_SKEY_1
	
	FROM
	(
	SELECT CUST_SKEY AS SKEY, CUST_SHIP_TO_REC_EFF_DT, CUST_SHIP_TO_REC_TRM_DT, CURR_REC_IND, CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, BIL_TO_SKEY, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, FED_TAX_PAYR_ID, SLSPN_CD, CUST_NM, ADDR_LINE_1_TXT, ADDR_LINE_3_TXT, ADDR_LINE_2_TXT, CTY_NM, STT_CD, CNTY_NM, ZIP_CD, CNTRY_CD, CUST_ALIAS_NM, CUST_CATGY_CD, MAJ_CLSS_CD, MNR_CLSS_CD, SORT_NM, APPL_STS_CD, ONE_TM_CUST_IND, ACT_INAC_IND, PAY_TERM_PLCY_CD, ACCT_GRP_CD, AGE_PLCY_CD, TEL_NBR, FAX_NBR, DLVR_CD, SHIP_TO_STOR_NBR, ORDR_APRV_RQR_IND, ACCT_TYP_CD, CORP_TYP_OF_OPER_CD, CUISINE_CD, out_PRFL_CREAT_DT PRFL_CREAT_DT, DFLT_SBST_TYP_CD, DFLT_RSTRC_TYP_CD, FRC_SBST_IND, DEPT_IND, PART_FILL_IND, NON_PRFT_IND, MISC_TAX_XMPT_IND, TERR_CD, DEPT_ID, DEPT_NM, DEPT_EMPLE_ID, RGN_ID, RGN_NM, RGN_EMPLE_ID, DIST_ID, DIST_NM, DIST_EMPLE_ID, TERR_NM, TERR_EMPLE_ID, IMMED_ALLOC_IND, CUST_SHIP_TO_STS_ID, ORDR_PL_IND, CUST_TYP_CD, CUST_CMDTY_CD, PREV_STS_ID, PAY_TERM_CD, LCL_TYP_OF_OPER_CD, out_STOP_DT STOP_DT, STOP_CNTR_VAL, PRC_RULE_NM, STOP_CD, TERR_OVRD_IND, CUST_ENTY_TYP_CD, CMDTY_IND, KOSHER_CUST_IND, PRM_SHIP_TO_NBR, DLVR_DFCLT_RTNG_ID, PRR_YR_RTNG_CD, PRR_MO_RTNG_CD, LCL_CUST_RTNG_CD, ESYSCO_CUST_IND, CUST_CRDT_LMT_BC_AMT, UNAPPL_CSH_BAL_BC_AMT, OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, out_ACCT_OPEN_DT AS ACCT_OPEN_DT, out_ACCT_CLOS_DT AS ACCT_CLOS_DT, CAST(out_FIRST_INVC_DT AS STRING) FIRST_INVC_DT, out_LST_INVC_DT AS LST_INVC_DT, LST_INVC_AMT_BC_AMT, out_LST_CSH_DT AS LST_CSH_DT, LST_CSH_AMT_BC_AMT, AR_TYP_CD, CRDT_STOP_APRV_PND_IND, TAX_XMPT_IND, LAT_COORD_VAL, LON_COORD_VAL, DIR_OF_LAT_ID, DIR_OF_LON_ID, SALE_LVL_ID, out_SRC_CREAT_DT SRC_CREAT_DT, INSRT_DTTM, UPDT_DTTM, SRC_SYS_CD, CORP_SHIP_TO_STOR_NBR, NET_DUE_GRACE_DAY_CD, DSCNT, DAY_IN_DSCNT_PRD, DAY_IN_NET_DUE_PRD, TERM_TYP, PAY_TERM_PLCY_DESC, SAP_IND, SAP_CUST_NBR, SAP_CUST_NM, SAP_ACCT_GRP_NM, SYSTEM_SIZE, NPD_SYSCO_SEGMENTATION, RTLR_FEIN_NBR, CUST_BEER_PRMT_NBR, '' AS ERR_FLG, REC_CNT
	FROM 
	CUST_SHIP_TO_INT WHERE out_PK_CHECK_FLAG='N' AND PROC_FLAG='PROCESS'
	
	UNION

	SELECT DM_TBL.CUST_SKEY AS SKEY, DM_TBL.CUST_SHIP_TO_REC_EFF_DT, 
	CASE WHEN DM_TBL.CUST_SHIP_TO_REC_EFF_DT >= CURRENT_DATE THEN DM_TBL.CUST_SHIP_TO_REC_EFF_DT ELSE date_sub(CURRENT_DATE,1) END AS CUST_SHIP_TO_REC_TRM_DT, 
	'N' AS CURR_REC_IND, 
	DM_TBL.CO_SKEY, DM_TBL.CUST_NBR, DM_TBL.VNDR_SKEY, DM_TBL.VNDR_SHIP_PT_SKEY, DM_TBL.BIL_TO_SKEY, DM_TBL.CORP_HIER_PRNT_CUST_SKEY, DM_TBL.CORP_HIER_MSTR_CUST_SKEY, DM_TBL.FED_TAX_PAYR_ID, DM_TBL.SLSPN_CD, DM_TBL.CUST_NM, DM_TBL.ADDR_LINE_1_TXT, DM_TBL.ADDR_LINE_3_TXT, DM_TBL.ADDR_LINE_2_TXT, DM_TBL.CTY_NM, DM_TBL.STT_CD, DM_TBL.CNTY_NM, DM_TBL.ZIP_CD, DM_TBL.CNTRY_CD, DM_TBL.CUST_ALIAS_NM, DM_TBL.CUST_CATGY_CD, DM_TBL.MAJ_CLSS_CD, DM_TBL.MNR_CLSS_CD, DM_TBL.SORT_NM, DM_TBL.APPL_STS_CD, DM_TBL.ONE_TM_CUST_IND, DM_TBL.ACT_INAC_IND, DM_TBL.PAY_TERM_PLCY_CD, DM_TBL.ACCT_GRP_CD, DM_TBL.AGE_PLCY_CD, DM_TBL.TEL_NBR, DM_TBL.FAX_NBR, DM_TBL.DLVR_CD, DM_TBL.SHIP_TO_STOR_NBR, DM_TBL.ORDR_APRV_RQR_IND, DM_TBL.ACCT_TYP_CD, DM_TBL.CORP_TYP_OF_OPER_CD, DM_TBL.CUISINE_CD, DM_TBL.PRFL_CREAT_DT, DM_TBL.DFLT_SBST_TYP_CD, DM_TBL.DFLT_RSTRC_TYP_CD, DM_TBL.FRC_SBST_IND, DM_TBL.DEPT_IND, DM_TBL.PART_FILL_IND, DM_TBL.NON_PRFT_IND, DM_TBL.MISC_TAX_XMPT_IND, DM_TBL.TERR_CD, DM_TBL.DEPT_ID, DM_TBL.DEPT_NM, DM_TBL.DEPT_EMPLE_ID, DM_TBL.RGN_ID, DM_TBL.RGN_NM, DM_TBL.RGN_EMPLE_ID, DM_TBL.DIST_ID, DM_TBL.DIST_NM, DM_TBL.DIST_EMPLE_ID, DM_TBL.TERR_NM, DM_TBL.TERR_EMPLE_ID, DM_TBL.IMMED_ALLOC_IND, DM_TBL.CUST_SHIP_TO_STS_ID, DM_TBL.ORDR_PL_IND, DM_TBL.CUST_TYP_CD, DM_TBL.CUST_CMDTY_CD, DM_TBL.PREV_STS_ID, DM_TBL.PAY_TERM_CD, DM_TBL.LCL_TYP_OF_OPER_CD, DM_TBL.STOP_DT, DM_TBL.STOP_CNTR_VAL, DM_TBL.PRC_RULE_NM, DM_TBL.STOP_CD, DM_TBL.TERR_OVRD_IND, DM_TBL.CUST_ENTY_TYP_CD, DM_TBL.CMDTY_IND, DM_TBL.KOSHER_CUST_IND, DM_TBL.PRM_SHIP_TO_NBR, DM_TBL.DLVR_DFCLT_RTNG_ID, DM_TBL.PRR_YR_RTNG_CD, DM_TBL.PRR_MO_RTNG_CD, DM_TBL.LCL_CUST_RTNG_CD, DM_TBL.ESYSCO_CUST_IND, DM_TBL.CUST_CRDT_LMT_BC_AMT, DM_TBL.UNAPPL_CSH_BAL_BC_AMT, DM_TBL.OPEN_ITM_BAL_BC_AMT, DM_TBL.OPEN_ITM_CNT, DM_TBL.ON_ORDR_AMT_STD_ORDR_BC_AMT, DM_TBL.ON_ORDR_AMT_DROP_SHIP_BC_AMT, DM_TBL.ACCT_OPEN_DT, DM_TBL.ACCT_CLOS_DT, CAST(DM_TBL.FIRST_INVC_DT AS STRING) FIRST_INVC_DT, DM_TBL.LST_INVC_DT, DM_TBL.LST_INVC_AMT_BC_AMT, DM_TBL.LST_CSH_DT, DM_TBL.LST_CSH_AMT_BC_AMT, DM_TBL.AR_TYP_CD, DM_TBL.CRDT_STOP_APRV_PND_IND, DM_TBL.TAX_XMPT_IND, DM_TBL.LAT_COORD_VAL, DM_TBL.LON_COORD_VAL, DM_TBL.DIR_OF_LAT_ID, DM_TBL.DIR_OF_LON_ID, DM_TBL.SALE_LVL_ID, DM_TBL.SRC_CREAT_DT, DM_TBL.INSRT_DTTM, DM_TBL.UPDT_DTTM, DM_TBL.SRC_SYS_CD, DM_TBL.CORP_SHIP_TO_STOR_NBR, DM_TBL.NET_DUE_GRACE_DAY_CD, DM_TBL.DSCNT, DM_TBL.DAY_IN_DSCNT_PRD, DM_TBL.DAY_IN_NET_DUE_PRD, DM_TBL.TERM_TYP, DM_TBL.PAY_TERM_PLCY_DESC, DM_TBL.SAP_IND, DM_TBL.SAP_CUST_NBR, DM_TBL.SAP_CUST_NM, DM_TBL.SAP_ACCT_GRP_NM, DM_TBL.SYSTEM_SIZE, DM_TBL.NPD_SYSCO_SEGMENTATION, DM_TBL.RTLR_FEIN_NBR, DM_TBL.CUST_BEER_PRMT_NBR, 
	CASE WHEN INT_TBL.SRC_SYS_CD='ERR' THEN 'FILTER' ELSE
         CASE WHEN DM_TBL.SRC_SYS_CD='ERR' THEN 'FULL_UPDATE' ELSE 'PROCESS' END END AS ERR_FLG, INT_TBL.REC_CNT
	FROM 
	rs_cust_ship_to_dim_mstr DM_TBL 
	INNER JOIN 
	CUST_SHIP_TO_INT INT_TBL ON INT_TBL.CO_SKEY=DM_TBL.CO_SKEY AND INT_TBL.CUST_NBR=DM_TBL.CUST_NBR 
	WHERE INT_TBL.out_PK_CHECK_FLAG='N' AND DM_TBL.CURR_REC_IND='Y' AND INT_TBL.PROC_FLAG='PROCESS' AND DM_TBL.CUST_SHIP_TO_REC_TRM_DT='9999-12-31'
	)A
	)B"""


cust_ship_to_dim_new_insert_query = """
SELECT 

SKEY_LKP.CUST_SKEY + ROW_NUMBER() OVER(PARTITION BY CUST_SHIP_TO_SCD.CO_SKEY ORDER BY CUST_NBR,CUST_SHIP_TO_SCD.CO_SKEY) AS CUST_SKEY, 

CUST_SHIP_TO_REC_EFF_DT, CUST_SHIP_TO_REC_TRM_DT, CURR_REC_IND, CUST_SHIP_TO_SCD.CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, BIL_TO_SKEY, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, FED_TAX_PAYR_ID, SLSPN_CD, CUST_NM, ADDR_LINE_1_TXT, ADDR_LINE_3_TXT, ADDR_LINE_2_TXT, CTY_NM, STT_CD, CNTY_NM, ZIP_CD, CNTRY_CD, CUST_ALIAS_NM, CUST_CATGY_CD, MAJ_CLSS_CD, MNR_CLSS_CD, SORT_NM, APPL_STS_CD, ONE_TM_CUST_IND, ACT_INAC_IND, PAY_TERM_PLCY_CD, ACCT_GRP_CD, AGE_PLCY_CD, TEL_NBR, FAX_NBR, DLVR_CD, SHIP_TO_STOR_NBR, ORDR_APRV_RQR_IND, ACCT_TYP_CD, CORP_TYP_OF_OPER_CD, CUISINE_CD, PRFL_CREAT_DT, DFLT_SBST_TYP_CD, DFLT_RSTRC_TYP_CD, FRC_SBST_IND, DEPT_IND, PART_FILL_IND, NON_PRFT_IND, MISC_TAX_XMPT_IND, TERR_CD, DEPT_ID, DEPT_NM, DEPT_EMPLE_ID, RGN_ID, RGN_NM, RGN_EMPLE_ID, DIST_ID, DIST_NM, DIST_EMPLE_ID, TERR_NM, TERR_EMPLE_ID, IMMED_ALLOC_IND, CUST_SHIP_TO_STS_ID, ORDR_PL_IND, CUST_TYP_CD, CUST_CMDTY_CD, PREV_STS_ID, PAY_TERM_CD, LCL_TYP_OF_OPER_CD, STOP_DT, STOP_CNTR_VAL, PRC_RULE_NM, STOP_CD, TERR_OVRD_IND, CUST_ENTY_TYP_CD, CMDTY_IND, KOSHER_CUST_IND, PRM_SHIP_TO_NBR, DLVR_DFCLT_RTNG_ID, PRR_YR_RTNG_CD, PRR_MO_RTNG_CD, LCL_CUST_RTNG_CD, ESYSCO_CUST_IND, CUST_CRDT_LMT_BC_AMT, UNAPPL_CSH_BAL_BC_AMT, OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, ACCT_OPEN_DT, ACCT_CLOS_DT, CAST(FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, LST_INVC_DT, LST_INVC_AMT_BC_AMT, LST_CSH_DT, LST_CSH_AMT_BC_AMT, AR_TYP_CD, CRDT_STOP_APRV_PND_IND, TAX_XMPT_IND, LAT_COORD_VAL, LON_COORD_VAL, DIR_OF_LAT_ID, DIR_OF_LON_ID, SALE_LVL_ID, SRC_CREAT_DT, INSRT_DTTM, UPDT_DTTM, SRC_SYS_CD, CORP_SHIP_TO_STOR_NBR, NET_DUE_GRACE_DAY_CD, DSCNT, DAY_IN_DSCNT_PRD, DAY_IN_NET_DUE_PRD, TERM_TYP, PAY_TERM_PLCY_DESC, SAP_IND, SAP_CUST_NBR, SAP_CUST_NM, SAP_ACCT_GRP_NM, SYSTEM_SIZE, NPD_SYSCO_SEGMENTATION, RTLR_FEIN_NBR, CUST_BEER_PRMT_NBR 
FROM 
CUST_SHIP_TO_SCD 
INNER JOIN 
rs_CUST_SKEY_LKP_mstr SKEY_LKP
ON CUST_SHIP_TO_SCD.CO_SKEY=SKEY_LKP.CO_SKEY AND INS='Y'"""

cust_ship_to_dim_major_query = """
	SELECT *, CASE WHEN ERR_FLG='' THEN LEAD(ERR_FLG,1) OVER(PARTITION BY CO_SKEY, CUST_NBR ORDER BY CURR_REC_IND DESC) ELSE ERR_FLG END AS ERR_PROC_FLG 
	FROM 
	CUST_SHIP_TO_SCD WHERE MAJ='Y'"""
	
cust_ship_to_dim_err_full_update = """
	SELECT CUST_SKEY, CUST_SHIP_TO_REC_EFF_DT, CUST_SHIP_TO_REC_TRM_DT, CURR_REC_IND, CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, BIL_TO_SKEY, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, FED_TAX_PAYR_ID, SLSPN_CD, CUST_NM, ADDR_LINE_1_TXT, ADDR_LINE_3_TXT, ADDR_LINE_2_TXT, CTY_NM, STT_CD, CNTY_NM, ZIP_CD, CNTRY_CD, CUST_ALIAS_NM, CUST_CATGY_CD, MAJ_CLSS_CD, MNR_CLSS_CD, SORT_NM, APPL_STS_CD, ONE_TM_CUST_IND, ACT_INAC_IND, PAY_TERM_PLCY_CD, ACCT_GRP_CD, AGE_PLCY_CD, TEL_NBR, FAX_NBR, DLVR_CD, SHIP_TO_STOR_NBR, ORDR_APRV_RQR_IND, ACCT_TYP_CD, CORP_TYP_OF_OPER_CD, CUISINE_CD, PRFL_CREAT_DT, DFLT_SBST_TYP_CD, DFLT_RSTRC_TYP_CD, FRC_SBST_IND, DEPT_IND, PART_FILL_IND, NON_PRFT_IND, MISC_TAX_XMPT_IND, TERR_CD, DEPT_ID, DEPT_NM, DEPT_EMPLE_ID, RGN_ID, RGN_NM, RGN_EMPLE_ID, DIST_ID, DIST_NM, DIST_EMPLE_ID, TERR_NM, TERR_EMPLE_ID, IMMED_ALLOC_IND, CUST_SHIP_TO_STS_ID, ORDR_PL_IND, CUST_TYP_CD, CUST_CMDTY_CD, PREV_STS_ID, PAY_TERM_CD, LCL_TYP_OF_OPER_CD, STOP_DT, STOP_CNTR_VAL, PRC_RULE_NM, STOP_CD, TERR_OVRD_IND, CUST_ENTY_TYP_CD, CMDTY_IND, KOSHER_CUST_IND, PRM_SHIP_TO_NBR, DLVR_DFCLT_RTNG_ID, PRR_YR_RTNG_CD, PRR_MO_RTNG_CD, LCL_CUST_RTNG_CD, ESYSCO_CUST_IND, CUST_CRDT_LMT_BC_AMT, UNAPPL_CSH_BAL_BC_AMT, OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, ACCT_OPEN_DT, ACCT_CLOS_DT, CAST(FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, LST_INVC_DT, LST_INVC_AMT_BC_AMT, LST_CSH_DT, LST_CSH_AMT_BC_AMT, AR_TYP_CD, CRDT_STOP_APRV_PND_IND, TAX_XMPT_IND, LAT_COORD_VAL, LON_COORD_VAL, DIR_OF_LAT_ID, DIR_OF_LON_ID, SALE_LVL_ID, SRC_CREAT_DT, INSRT_DTTM, UPDT_DTTM, SRC_SYS_CD, CORP_SHIP_TO_STOR_NBR, NET_DUE_GRACE_DAY_CD, DSCNT, DAY_IN_DSCNT_PRD, DAY_IN_NET_DUE_PRD, TERM_TYP, PAY_TERM_PLCY_DESC, SAP_IND, SAP_CUST_NBR, SAP_CUST_NM, SAP_ACCT_GRP_NM, SYSTEM_SIZE, NPD_SYSCO_SEGMENTATION, RTLR_FEIN_NBR, CUST_BEER_PRMT_NBR
	FROM 
	CUST_SHIP_TO_DIM_MAJOR 
	WHERE ERR_PROC_FLG='FULL_UPDATE' AND CURR_REC_IND='Y'"""
	
cust_ship_to_dim_major_process_query="""
	SELECT CUST_SKEY, 	
	CASE WHEN CURR_REC_IND='Y' THEN CURRENT_DATE ELSE CUST_SHIP_TO_REC_EFF_DT END AS CUST_SHIP_TO_REC_EFF_DT,
	CUST_SHIP_TO_REC_TRM_DT, CURR_REC_IND, CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, BIL_TO_SKEY, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, FED_TAX_PAYR_ID, SLSPN_CD, CUST_NM, ADDR_LINE_1_TXT, ADDR_LINE_3_TXT, ADDR_LINE_2_TXT, CTY_NM, STT_CD, CNTY_NM, ZIP_CD, CNTRY_CD, CUST_ALIAS_NM, CUST_CATGY_CD, MAJ_CLSS_CD, MNR_CLSS_CD, SORT_NM, APPL_STS_CD, ONE_TM_CUST_IND, ACT_INAC_IND, PAY_TERM_PLCY_CD, ACCT_GRP_CD, AGE_PLCY_CD, TEL_NBR, FAX_NBR, DLVR_CD, SHIP_TO_STOR_NBR, ORDR_APRV_RQR_IND, ACCT_TYP_CD, CORP_TYP_OF_OPER_CD, CUISINE_CD, PRFL_CREAT_DT, DFLT_SBST_TYP_CD, DFLT_RSTRC_TYP_CD, FRC_SBST_IND, DEPT_IND, PART_FILL_IND, NON_PRFT_IND, MISC_TAX_XMPT_IND, TERR_CD, DEPT_ID, DEPT_NM, DEPT_EMPLE_ID, RGN_ID, RGN_NM, RGN_EMPLE_ID, DIST_ID, DIST_NM, DIST_EMPLE_ID, TERR_NM, TERR_EMPLE_ID, IMMED_ALLOC_IND, CUST_SHIP_TO_STS_ID, ORDR_PL_IND, CUST_TYP_CD, CUST_CMDTY_CD, PREV_STS_ID, PAY_TERM_CD, LCL_TYP_OF_OPER_CD, STOP_DT, STOP_CNTR_VAL, PRC_RULE_NM, STOP_CD, TERR_OVRD_IND, CUST_ENTY_TYP_CD, CMDTY_IND, KOSHER_CUST_IND, PRM_SHIP_TO_NBR, DLVR_DFCLT_RTNG_ID, PRR_YR_RTNG_CD, PRR_MO_RTNG_CD, LCL_CUST_RTNG_CD, ESYSCO_CUST_IND, CUST_CRDT_LMT_BC_AMT, UNAPPL_CSH_BAL_BC_AMT, OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, ACCT_OPEN_DT, ACCT_CLOS_DT, CAST(FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, LST_INVC_DT, LST_INVC_AMT_BC_AMT, LST_CSH_DT, LST_CSH_AMT_BC_AMT, AR_TYP_CD, CRDT_STOP_APRV_PND_IND, TAX_XMPT_IND, LAT_COORD_VAL, LON_COORD_VAL, DIR_OF_LAT_ID, DIR_OF_LON_ID, SALE_LVL_ID, SRC_CREAT_DT, INSRT_DTTM, CURRENT_TIMESTAMP AS UPDT_DTTM, SRC_SYS_CD, CORP_SHIP_TO_STOR_NBR, NET_DUE_GRACE_DAY_CD, DSCNT, DAY_IN_DSCNT_PRD, DAY_IN_NET_DUE_PRD, TERM_TYP, PAY_TERM_PLCY_DESC, SAP_IND, SAP_CUST_NBR, SAP_CUST_NM, SAP_ACCT_GRP_NM, SYSTEM_SIZE, NPD_SYSCO_SEGMENTATION, RTLR_FEIN_NBR, CUST_BEER_PRMT_NBR 
	FROM CUST_SHIP_TO_DIM_MAJOR 
	WHERE ERR_PROC_FLG='PROCESS'"""


cust_ship_to_dim_minor_query="""
	SELECT DISTINCT CUST_SKEY, CUST_SHIP_TO_REC_EFF_DT, CUST_SHIP_TO_REC_TRM_DT, CURR_REC_IND, CO_SKEY, CUST_NBR, VNDR_SKEY, VNDR_SHIP_PT_SKEY, BIL_TO_SKEY, CORP_HIER_PRNT_CUST_SKEY, CORP_HIER_MSTR_CUST_SKEY, FED_TAX_PAYR_ID, SLSPN_CD, CUST_NM, ADDR_LINE_1_TXT, ADDR_LINE_3_TXT, ADDR_LINE_2_TXT, CTY_NM, STT_CD, CNTY_NM, ZIP_CD, CNTRY_CD, CUST_ALIAS_NM, CUST_CATGY_CD, MAJ_CLSS_CD, MNR_CLSS_CD, SORT_NM, APPL_STS_CD, ONE_TM_CUST_IND, ACT_INAC_IND, PAY_TERM_PLCY_CD, ACCT_GRP_CD, AGE_PLCY_CD, TEL_NBR, FAX_NBR, DLVR_CD, SHIP_TO_STOR_NBR, ORDR_APRV_RQR_IND, ACCT_TYP_CD, CORP_TYP_OF_OPER_CD, CUISINE_CD, PRFL_CREAT_DT, DFLT_SBST_TYP_CD, DFLT_RSTRC_TYP_CD, FRC_SBST_IND, DEPT_IND, PART_FILL_IND, NON_PRFT_IND, MISC_TAX_XMPT_IND, TERR_CD, DEPT_ID, DEPT_NM, DEPT_EMPLE_ID, RGN_ID, RGN_NM, RGN_EMPLE_ID, DIST_ID, DIST_NM, DIST_EMPLE_ID, TERR_NM, TERR_EMPLE_ID, IMMED_ALLOC_IND, CUST_SHIP_TO_STS_ID, ORDR_PL_IND, CUST_TYP_CD, CUST_CMDTY_CD, PREV_STS_ID, PAY_TERM_CD, LCL_TYP_OF_OPER_CD, STOP_DT, STOP_CNTR_VAL, PRC_RULE_NM, STOP_CD, TERR_OVRD_IND, CUST_ENTY_TYP_CD, CMDTY_IND, KOSHER_CUST_IND, PRM_SHIP_TO_NBR, DLVR_DFCLT_RTNG_ID, PRR_YR_RTNG_CD, PRR_MO_RTNG_CD, LCL_CUST_RTNG_CD, ESYSCO_CUST_IND, CUST_CRDT_LMT_BC_AMT, UNAPPL_CSH_BAL_BC_AMT, OPEN_ITM_BAL_BC_AMT, OPEN_ITM_CNT, ON_ORDR_AMT_STD_ORDR_BC_AMT, ON_ORDR_AMT_DROP_SHIP_BC_AMT, ACCT_OPEN_DT, ACCT_CLOS_DT, CAST(FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, LST_INVC_DT, LST_INVC_AMT_BC_AMT, LST_CSH_DT, LST_CSH_AMT_BC_AMT, AR_TYP_CD, CRDT_STOP_APRV_PND_IND, TAX_XMPT_IND, LAT_COORD_VAL, LON_COORD_VAL, DIR_OF_LAT_ID, DIR_OF_LON_ID, SALE_LVL_ID, SRC_CREAT_DT, INSRT_DTTM, UPDT_DTTM, SRC_SYS_CD, CORP_SHIP_TO_STOR_NBR, NET_DUE_GRACE_DAY_CD, DSCNT, DAY_IN_DSCNT_PRD, DAY_IN_NET_DUE_PRD, TERM_TYP, PAY_TERM_PLCY_DESC, SAP_IND, SAP_CUST_NBR, SAP_CUST_NM, SAP_ACCT_GRP_NM, SYSTEM_SIZE, NPD_SYSCO_SEGMENTATION, RTLR_FEIN_NBR, CUST_BEER_PRMT_NBR  
	FROM CUST_SHIP_TO_SCD WHERE MNR='Y' AND CURR_REC_IND='Y'"""
	
minor_update_query="""
(SELECT DM_TBL.CUST_SKEY, DM_TBL.CUST_SHIP_TO_REC_EFF_DT, DM_TBL.CUST_SHIP_TO_REC_TRM_DT, DM_TBL.CURR_REC_IND, DM_TBL.CO_SKEY, DM_TBL.CUST_NBR, SCD_TBL.VNDR_SKEY, SCD_TBL.VNDR_SHIP_PT_SKEY, SCD_TBL.BIL_TO_SKEY, DM_TBL.CORP_HIER_PRNT_CUST_SKEY, DM_TBL.CORP_HIER_MSTR_CUST_SKEY, SCD_TBL.FED_TAX_PAYR_ID, DM_TBL.SLSPN_CD, SCD_TBL.CUST_NM, SCD_TBL.ADDR_LINE_1_TXT, SCD_TBL.ADDR_LINE_3_TXT, SCD_TBL.ADDR_LINE_2_TXT, SCD_TBL.CTY_NM, SCD_TBL.STT_CD, SCD_TBL.CNTY_NM, SCD_TBL.ZIP_CD, SCD_TBL.CNTRY_CD, DM_TBL.CUST_ALIAS_NM, SCD_TBL.CUST_CATGY_CD, SCD_TBL.MAJ_CLSS_CD, SCD_TBL.MNR_CLSS_CD, SCD_TBL.SORT_NM, SCD_TBL.APPL_STS_CD, SCD_TBL.ONE_TM_CUST_IND, DM_TBL.ACT_INAC_IND, DM_TBL.PAY_TERM_PLCY_CD, SCD_TBL.ACCT_GRP_CD, SCD_TBL.AGE_PLCY_CD, SCD_TBL.TEL_NBR, SCD_TBL.FAX_NBR, SCD_TBL.DLVR_CD, SCD_TBL.SHIP_TO_STOR_NBR, SCD_TBL.ORDR_APRV_RQR_IND, DM_TBL.ACCT_TYP_CD, DM_TBL.CORP_TYP_OF_OPER_CD, SCD_TBL.CUISINE_CD, SCD_TBL.PRFL_CREAT_DT, SCD_TBL.DFLT_SBST_TYP_CD, SCD_TBL.DFLT_RSTRC_TYP_CD, SCD_TBL.FRC_SBST_IND, SCD_TBL.DEPT_IND, SCD_TBL.PART_FILL_IND, SCD_TBL.NON_PRFT_IND, SCD_TBL.MISC_TAX_XMPT_IND, DM_TBL.TERR_CD, SCD_TBL.DEPT_ID, SCD_TBL.DEPT_NM, SCD_TBL.DEPT_EMPLE_ID, SCD_TBL.RGN_ID, SCD_TBL.RGN_NM, SCD_TBL.RGN_EMPLE_ID, SCD_TBL.DIST_ID, SCD_TBL.DIST_NM, SCD_TBL.DIST_EMPLE_ID, SCD_TBL.TERR_NM, SCD_TBL.TERR_EMPLE_ID, SCD_TBL.IMMED_ALLOC_IND, DM_TBL.CUST_SHIP_TO_STS_ID, SCD_TBL.ORDR_PL_IND, DM_TBL.CUST_TYP_CD, SCD_TBL.CUST_CMDTY_CD, SCD_TBL.PREV_STS_ID, DM_TBL.PAY_TERM_CD, DM_TBL.LCL_TYP_OF_OPER_CD, SCD_TBL.STOP_DT, SCD_TBL.STOP_CNTR_VAL, DM_TBL.PRC_RULE_NM, DM_TBL.STOP_CD, SCD_TBL.TERR_OVRD_IND, SCD_TBL.CUST_ENTY_TYP_CD, SCD_TBL.CMDTY_IND, SCD_TBL.KOSHER_CUST_IND, DM_TBL.PRM_SHIP_TO_NBR, SCD_TBL.DLVR_DFCLT_RTNG_ID, DM_TBL.PRR_YR_RTNG_CD, DM_TBL.PRR_MO_RTNG_CD, DM_TBL.LCL_CUST_RTNG_CD, SCD_TBL.ESYSCO_CUST_IND, SCD_TBL.CUST_CRDT_LMT_BC_AMT, SCD_TBL.UNAPPL_CSH_BAL_BC_AMT, SCD_TBL.OPEN_ITM_BAL_BC_AMT, SCD_TBL.OPEN_ITM_CNT, SCD_TBL.ON_ORDR_AMT_STD_ORDR_BC_AMT, SCD_TBL.ON_ORDR_AMT_DROP_SHIP_BC_AMT, SCD_TBL.ACCT_OPEN_DT, SCD_TBL.ACCT_CLOS_DT, CAST(SCD_TBL.FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, SCD_TBL.LST_INVC_DT, SCD_TBL.LST_INVC_AMT_BC_AMT, SCD_TBL.LST_CSH_DT, SCD_TBL.LST_CSH_AMT_BC_AMT, SCD_TBL.AR_TYP_CD, SCD_TBL.CRDT_STOP_APRV_PND_IND, SCD_TBL.TAX_XMPT_IND, SCD_TBL.LAT_COORD_VAL, SCD_TBL.LON_COORD_VAL, SCD_TBL.DIR_OF_LAT_ID, SCD_TBL.DIR_OF_LON_ID, SCD_TBL.SALE_LVL_ID, DM_TBL.SRC_CREAT_DT, DM_TBL.INSRT_DTTM, CURRENT_TIMESTAMP AS UPDT_DTTM, DM_TBL.SRC_SYS_CD, 
CASE WHEN SCD_TBL.REC_CNT = 0 THEN DM_TBL.CORP_SHIP_TO_STOR_NBR ELSE SCD_TBL.CORP_SHIP_TO_STOR_NBR END AS CORP_SHIP_TO_STOR_NBR, 
DM_TBL.NET_DUE_GRACE_DAY_CD, DM_TBL.DSCNT, DM_TBL.DAY_IN_DSCNT_PRD, DM_TBL.DAY_IN_NET_DUE_PRD, DM_TBL.TERM_TYP, DM_TBL.PAY_TERM_PLCY_DESC, DM_TBL.SAP_IND, DM_TBL.SAP_CUST_NBR, DM_TBL.SAP_CUST_NM, DM_TBL.SAP_ACCT_GRP_NM, DM_TBL.SYSTEM_SIZE, DM_TBL.NPD_SYSCO_SEGMENTATION, SCD_TBL.RTLR_FEIN_NBR, SCD_TBL.CUST_BEER_PRMT_NBR	
FROM rs_cust_ship_to_dim_mstr DM_TBL 
INNER JOIN 
CUST_SHIP_TO_SCD SCD_TBL ON  
DM_TBL.CO_SKEY=SCD_TBL.CO_SKEY AND DM_TBL.CUST_NBR=SCD_TBL.CUST_NBR AND SCD_TBL.MNR='Y' AND SCD_TBL.CURR_REC_IND='Y' AND SCD_TBL.SRC_SYS_CD <> 'ERR' AND DM_TBL.SRC_SYS_CD IN ('SUS','MVS','FP')
	
UNION ALL

SELECT DM_TBL.CUST_SKEY, CAST(DM_TBL.CUST_SHIP_TO_REC_EFF_DT AS STRING) AS CUST_SHIP_TO_REC_EFF_DT, DM_TBL.CUST_SHIP_TO_REC_TRM_DT, DM_TBL.CURR_REC_IND, DM_TBL.CO_SKEY, DM_TBL.CUST_NBR, SCD_TBL.VNDR_SKEY, SCD_TBL.VNDR_SHIP_PT_SKEY, SCD_TBL.BIL_TO_SKEY, DM_TBL.CORP_HIER_PRNT_CUST_SKEY, DM_TBL.CORP_HIER_MSTR_CUST_SKEY, SCD_TBL.FED_TAX_PAYR_ID, DM_TBL.SLSPN_CD, SCD_TBL.CUST_NM, SCD_TBL.ADDR_LINE_1_TXT, SCD_TBL.ADDR_LINE_3_TXT, SCD_TBL.ADDR_LINE_2_TXT, SCD_TBL.CTY_NM, SCD_TBL.STT_CD, SCD_TBL.CNTY_NM, SCD_TBL.ZIP_CD, SCD_TBL.CNTRY_CD, DM_TBL.CUST_ALIAS_NM, SCD_TBL.CUST_CATGY_CD, SCD_TBL.MAJ_CLSS_CD, SCD_TBL.MNR_CLSS_CD, SCD_TBL.SORT_NM, SCD_TBL.APPL_STS_CD, SCD_TBL.ONE_TM_CUST_IND, DM_TBL.ACT_INAC_IND, DM_TBL.PAY_TERM_PLCY_CD, SCD_TBL.ACCT_GRP_CD, SCD_TBL.AGE_PLCY_CD, SCD_TBL.TEL_NBR, SCD_TBL.FAX_NBR, SCD_TBL.DLVR_CD, SCD_TBL.SHIP_TO_STOR_NBR, SCD_TBL.ORDR_APRV_RQR_IND, DM_TBL.ACCT_TYP_CD, DM_TBL.CORP_TYP_OF_OPER_CD, SCD_TBL.CUISINE_CD, SCD_TBL.PRFL_CREAT_DT, SCD_TBL.DFLT_SBST_TYP_CD, SCD_TBL.DFLT_RSTRC_TYP_CD, SCD_TBL.FRC_SBST_IND, SCD_TBL.DEPT_IND, SCD_TBL.PART_FILL_IND, SCD_TBL.NON_PRFT_IND, SCD_TBL.MISC_TAX_XMPT_IND, DM_TBL.TERR_CD, SCD_TBL.DEPT_ID, SCD_TBL.DEPT_NM, SCD_TBL.DEPT_EMPLE_ID, SCD_TBL.RGN_ID, SCD_TBL.RGN_NM, SCD_TBL.RGN_EMPLE_ID, SCD_TBL.DIST_ID, SCD_TBL.DIST_NM, SCD_TBL.DIST_EMPLE_ID, SCD_TBL.TERR_NM, SCD_TBL.TERR_EMPLE_ID, SCD_TBL.IMMED_ALLOC_IND, DM_TBL.CUST_SHIP_TO_STS_ID, SCD_TBL.ORDR_PL_IND, DM_TBL.CUST_TYP_CD, SCD_TBL.CUST_CMDTY_CD, SCD_TBL.PREV_STS_ID, DM_TBL.PAY_TERM_CD, DM_TBL.LCL_TYP_OF_OPER_CD, SCD_TBL.STOP_DT, SCD_TBL.STOP_CNTR_VAL, DM_TBL.PRC_RULE_NM, DM_TBL.STOP_CD, SCD_TBL.TERR_OVRD_IND, SCD_TBL.CUST_ENTY_TYP_CD, SCD_TBL.CMDTY_IND, SCD_TBL.KOSHER_CUST_IND, DM_TBL.PRM_SHIP_TO_NBR, SCD_TBL.DLVR_DFCLT_RTNG_ID, DM_TBL.PRR_YR_RTNG_CD, DM_TBL.PRR_MO_RTNG_CD, DM_TBL.LCL_CUST_RTNG_CD, SCD_TBL.ESYSCO_CUST_IND, SCD_TBL.CUST_CRDT_LMT_BC_AMT, SCD_TBL.UNAPPL_CSH_BAL_BC_AMT, SCD_TBL.OPEN_ITM_BAL_BC_AMT, SCD_TBL.OPEN_ITM_CNT, SCD_TBL.ON_ORDR_AMT_STD_ORDR_BC_AMT, SCD_TBL.ON_ORDR_AMT_DROP_SHIP_BC_AMT, SCD_TBL.ACCT_OPEN_DT, SCD_TBL.ACCT_CLOS_DT, CAST(SCD_TBL.FIRST_INVC_DT AS STRING) AS FIRST_INVC_DT, SCD_TBL.LST_INVC_DT, SCD_TBL.LST_INVC_AMT_BC_AMT, SCD_TBL.LST_CSH_DT, SCD_TBL.LST_CSH_AMT_BC_AMT, SCD_TBL.AR_TYP_CD, SCD_TBL.CRDT_STOP_APRV_PND_IND, SCD_TBL.TAX_XMPT_IND, SCD_TBL.LAT_COORD_VAL, SCD_TBL.LON_COORD_VAL, SCD_TBL.DIR_OF_LAT_ID, SCD_TBL.DIR_OF_LON_ID, SCD_TBL.SALE_LVL_ID, DM_TBL.SRC_CREAT_DT, DM_TBL.INSRT_DTTM, CURRENT_TIMESTAMP AS UPDT_DTTM, DM_TBL.SRC_SYS_CD, 
CASE WHEN SCD_TBL.REC_CNT = 0 THEN DM_TBL.CORP_SHIP_TO_STOR_NBR ELSE SCD_TBL.CORP_SHIP_TO_STOR_NBR END AS CORP_SHIP_TO_STOR_NBR, 
DM_TBL.NET_DUE_GRACE_DAY_CD, DM_TBL.DSCNT, DM_TBL.DAY_IN_DSCNT_PRD, DM_TBL.DAY_IN_NET_DUE_PRD, DM_TBL.TERM_TYP, DM_TBL.PAY_TERM_PLCY_DESC, DM_TBL.SAP_IND, DM_TBL.SAP_CUST_NBR, DM_TBL.SAP_CUST_NM, DM_TBL.SAP_ACCT_GRP_NM, DM_TBL.SYSTEM_SIZE, DM_TBL.NPD_SYSCO_SEGMENTATION, SCD_TBL.RTLR_FEIN_NBR, SCD_TBL.CUST_BEER_PRMT_NBR	

FROM rs_cust_ship_to_dim_mstr DM_TBL 
INNER JOIN 
CUST_SHIP_TO_SCD SCD_TBL ON  
DM_TBL.CO_SKEY=SCD_TBL.CO_SKEY AND DM_TBL.CUST_NBR=SCD_TBL.CUST_NBR AND (SCD_TBL.MNR='Y') AND SCD_TBL.CURR_REC_IND='Y' AND SCD_TBL.SRC_SYS_CD <> 'ERR' AND DM_TBL.SRC_SYS_CD = 'BT'		
)"""


