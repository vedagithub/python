 #################################################################################################################
##	Usage  : cust_ship_to_dim.py <Company Numbers>	 	 			 
##										                             
##	Source : CUST_SHIP_TO							     			                              
##                                                                   
##	Target : CUST_SHIP_TO_DIM                           			 
##                                                                   
##	Purpose: TO PERFORM RI CHECK FOR CUST_SHIP_TO SOURCE AND APPLY THE BUSINESS LOGIC AND LOAD THE DATA INTO   	 
##           CUST_SHIP_TO_DIM TABLE								      
 ##################################################################### ############################################
import sys
sys.path.append('/home/hadoop/')
import time
import logging
import datetime
import os.path
import traceback
from pyspark import StorageLevel
import common.config as config
import common.common_func as common_func
import cust_ship_to_dim_sql as query_file


def registerHiveRedshiftTable(hive_context,co_nbr_list):
	
	#Registering spark data frame for Source Hive table CUST_SHIP_TO
	cust_ship_to_data_frame = common_func.registerSourceHiveTable(hive_context, config.srcHiveDatabase,'cust_ship_to_syg', '*', co_nbr_list, key_cols='CO_NBR, CUST_NBR', orderby_cols='SRC_SYS_CD  DESC, INSRT_DTTM DESC')
	cust_ship_to_data_frame.persist(StorageLevel.MEMORY_ONLY)
	cust_ship_to_data_frame.registerTempTable('hive_cust_ship_to_src')
	
	#Registering spark data frame for Redshift table ORG_CO_DIM	
	org_co_dim_data_frame = common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT CO_NBR,CO_SKEY, RDC_IND, CO_TYP_IND, SAP_IND from {}.ORG_CO_DIM )".format(config.dataMartSchema),"org_co_dim")
	org_co_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Redshift table VNDR_DIM	
	vndr_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT (CASE WHEN VNDR_NBR='UNKNOWN' THEN '' ELSE VNDR_NBR END) as VNDR_NBR,VNDR_SKEY,CURR_REC_IND FROM {}.VNDR_DIM WHERE CURR_REC_IND='Y')".format(config.dataMartSchema),"vndr_dim")
	vndr_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Redshift table VNDR_SHIP_FROM_DIM	
	vndr_ship_from_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT VNDR_SHIP_FROM_SKEY, VNDR_SKEY,VNDR_SHIP_PT_NBR,CURR_REC_IND FROM {}.VNDR_SHIP_FROM_DIM WHERE CURR_REC_IND = 'Y')".format(config.dataMartSchema),"vndr_ship_from_dim")
	vndr_ship_from_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Redshift table CUST_BIL_TO_DIM	
	cust_bil_to_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT BIL_TO_SKEY,DFLT_PAY_TERM_PLCY_CD,CO_SKEY,BIL_TO_NBR,CURR_REC_IND  FROM {}.CUST_BIL_TO_DIM WHERE CURR_REC_IND='Y' AND (CO_SKEY IN ({}) OR '000' IN ({})))".format(config.dataMartSchema,co_nbr_list,co_nbr_list),"cust_bil_to_dim")
	cust_bil_to_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Redshift table CUST_MISC	
	cust_misc_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT CUST_MISC.CUST_STOR_NBR as CUST_STOR_NBR, TRIM(CUST_MISC.CO_NBR) as CO_NBR, CUST_MISC.CUST_NBR as CUST_NBR, COUNT(1) OVER() AS REC_CNT FROM {}.CUST_MISC WHERE TRIM(CO_NBR) IN ({}) OR '000' IN ({}))".format(config.landingSchema,co_nbr_list,co_nbr_list),"cust_misc")
	
	#Registering spark data frame for Redshift table CUST_MSTR_PRNT_CUST_DIM	
	cust_mstr_prnt_cust_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT PRNT_CUST_SKEY ,CO_SKEY,(CASE WHEN TRIM(PRNT_CUST_NBR) ='UNKNOWN' THEN '' ELSE PRNT_CUST_NBR END)as PRNT_CUST_NBR FROM {}.CUST_MSTR_PRNT_CUST_DIM )".format(config.dataMartSchema),"cust_mstr_prnt_cust_dim")
	cust_mstr_prnt_cust_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Lookup query CUST_STOR_RQR_IND_CHECK	
	cust_stor_rqr_ind_check_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT distinct C.CO_SKEY AS CO_SKEY, C.CUST_NBR AS CUST_NBR 	FROM  {}.CUST_MUA_CUST_GRP_LNK_REL A 	INNER JOIN  {}.CUST_MUA_CUST_GRP_DIM B ON A.MUA_SB_ACCT_ID=B.MUA_GRP_ID AND B.CURR_REC_IND='Y' AND B.CUST_STOR_RQR_IND='Y' 	INNER JOIN {}.CUST_SHIP_TO_DIM C ON A.CUST_SKEY=C.CUST_SKEY AND CUST_GRP_LNK_BEGN_DT BETWEEN CUST_SHIP_TO_REC_EFF_DT AND CUST_SHIP_TO_REC_TRM_DT where(A.CUST_SKEY,A.CUST_GRP_LNK_BEGN_DT) IN (SELECT CUST_SKEY, MAX(CUST_GRP_LNK_BEGN_DT) CUST_GRP_LNK_BEGN_DT FROM {}.CUST_MUA_CUST_GRP_LNK_REL WHERE MNG_TYP_ID<>'T' GROUP BY CUST_SKEY) 	AND (C.CO_SKEY IN ({}) OR '000' IN ({})))".format(config.dataMartSchema,config.dataMartSchema,config.dataMartSchema,config.dataMartSchema,co_nbr_list,co_nbr_list),"cust_stor_rqr_ind_check")
	
	#Registering spark data frame for Redshift table VNDR_CO_VNDR_REL
	vndr_co_vndr_rel_query="""(SELECT DISTINCT VNDR_SKEY,CO_SKEY,CURR_REC_IND FROM {}.VNDR_CO_VNDR_REL
	WHERE CURR_REC_IND='Y' AND (CO_SKEY IN ({}) OR '000' IN ({})))""".format(config.dataMartSchema,co_nbr_list,co_nbr_list)
	vndr_co_vndr_rel_data_frame=common_func.registerRedshiftTable(hive_context,vndr_co_vndr_rel_query,"VNDR_CO_VNDR")
	
	#Registering spark data frame for Redshift table VNDR_CO_VNDR_SHIP_FROM_REL
	vndr_co_vndr_ship_from_rel_query="""(SELECT DISTINCT VNDR_SKEY, CO_SKEY, VNDR_SHIP_FROM_SKEY, CURR_REC_IND FROM {}.VNDR_CO_VNDR_SHIP_FROM_REL
	WHERE CURR_REC_IND='Y' AND (CO_SKEY IN ({}) OR '000' IN ({})))""".format(config.dataMartSchema,co_nbr_list,co_nbr_list)
	vndr_co_vndr_ship_from_rel_data_frame=common_func.registerRedshiftTable(hive_context,vndr_co_vndr_ship_from_rel_query,"VNDR_CO_VNDR_SHIP_FROM")
	
	#Registering spark data frame for Redshift table ORG_SALE_HIER_REL	
	org_sale_hier_rel_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT ORG_SALE_HIER_REL.DEPT_ID as DEPT_ID, ORG_SALE_HIER_REL.DEPT_NM as DEPT_NM, ORG_SALE_HIER_REL.DEPT_EMPLE_ID as DEPT_EMPLE_ID, ORG_SALE_HIER_REL.RGN_ID as RGN_ID, ORG_SALE_HIER_REL.RGN_NM as RGN_NM, ORG_SALE_HIER_REL.RGN_EMPLE_ID as RGN_EMPLE_ID, ORG_SALE_HIER_REL.DIST_ID as DIST_ID, ORG_SALE_HIER_REL.DIST_NM as DIST_NM, ORG_SALE_HIER_REL.DIST_EMPLE_ID as DIST_EMPLE_ID, ORG_SALE_HIER_REL.TERR_NM as TERR_NM, ORG_SALE_HIER_REL.TERR_EMPLE_ID as TERR_EMPLE_ID, ORG_SALE_HIER_REL.CO_SKEY as CO_SKEY, ORG_SALE_HIER_REL.TERR_CD as TERR_CD, CURR_REC_IND FROM {}.ORG_SALE_HIER_REL WHERE CURR_REC_IND='Y' AND (CO_SKEY IN ({}) OR '000' IN ({})))".format(config.dataMartSchema, co_nbr_list, co_nbr_list),"org_sale_hier_rel")
	org_sale_hier_rel_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	#Registering spark data frame for Redshift table NPD_UPD_SYSCO	
	#npd_upd_sysco_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT CO_SKEY,CUST_NBR,SYSTEM_SIZE,NPD_SYSCO_SEGMENTATION FROM {}.NPD_UPD_SYSCO WHERE (CO_SKEY,CUST_NBR,NPD_RECORD_ID) IN (SELECT CO_SKEY,CUST_NBR, MIN(NPD_RECORD_ID) FROM {}.NPD_UPD_SYSCO WHERE CO_SKEY IN ({}) OR '000' IN ({}) GROUP BY CO_SKEY,CUST_NBR))".format(config.dataMartSchema, config.dataMartSchema, co_nbr_list, co_nbr_list),"npd_upd_sysco")
	
	npd_upd_sysco_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT CO_SKEY,CUST_NBR,SYSTEM_SIZE,NPD_SYSCO_SEGMENTATION,NAME FROM {}.NPD_UPD_SYSCO WHERE CO_SKEY IN ({}) OR '000' IN ({}))".format(config.dataMartSchema, co_nbr_list, co_nbr_list),"npd_upd_sysco")
	npd_upd_sysco_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	npd_upd_sysco_unique_data_frame=hive_context.sql("""SELECT DISTINCT CO_SKEY,CUST_NBR,SYSTEM_SIZE,NPD_SYSCO_SEGMENTATION FROM 
	(SELECT CO_SKEY,CUST_NBR, SYSTEM_SIZE,NPD_SYSCO_SEGMENTATION, row_number() over(partition by CO_SKEY,CUST_NBR ORDER BY CO_SKEY,CUST_NBR,NAME) rn FROM rs_NPD_UPD_SYSCO_mstr) A 
	WHERE rn = 1""")
	npd_upd_sysco_unique_data_frame.registerTempTable('npd_upd_sysco_unique')
	
	#Registering spark data frame for Redshift table CUST_SKEY_LKP	
	cust_skey_lkp_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT CO_SKEY, CUST_SKEY FROM {}.CUST_SKEY_LKP WHERE CO_SKEY IN ({}) OR '000' IN ({}))".format(config.dataMartSchema, co_nbr_list,co_nbr_list),"cust_skey_lkp")
	
	#Registering spark data frame for Redshift table SALE_BUS_TRNSF_S2S_HIST	
	sale_bus_trnsf_s2s_hist_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT TO_CUST_NBR,TO_CO_NBR,TRNSF_TYP_CD,MAX(FROM_CUST_NBR) FROM_CUST_NBR, TO_NUMBER(TO_CO_NBR,999) AS CO_SKEY FROM {}.SALE_BUS_TRNSF_S2S_HIST WHERE TRNSF_TYP_CD='SAPToSUS' AND (TO_CO_NBR IN ({}) OR '000' IN ({})) GROUP BY TO_CUST_NBR,TO_CO_NBR,TRNSF_TYP_CD)".format(config.dataMartSchema, co_nbr_list, co_nbr_list),"sale_bus_trnsf_s2s_hist")
	
	#Registering spark data frame for Redshift table CUST_XREF_SAP_REL
	cust_xref_sap_rel_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT DISTINCT TO_NUMBER(LGCY_CO_NBR,999) AS CO_SKEY, LGCY_CUST_NBR, LGCY_CO_NBR, CUST_NBR, CUST_ACCT_GRP_NM, CUST_ORIG_NM, CUST_TYP_CD, VNDR_NBR, INSRT_DTTM, SRC_SYS_CD, TERR_CD, PRM_SHIP_TO_NBR, CUST_PRM_NM FROM {}.CUST_XREF_SAP_REL SAP_REL WHERE LGCY_CO_NBR IN ({}) OR '000' IN ({}))".format(config.dataMartSchema, co_nbr_list,co_nbr_list),"cust_xref_sap_rel")
	
	return {'cust_ship_to_data_frame':cust_ship_to_data_frame,'org_co_dim_data_frame':org_co_dim_data_frame,'vndr_dim_data_frame':vndr_dim_data_frame,'vndr_ship_from_dim_data_frame':vndr_ship_from_dim_data_frame,'cust_bil_to_dim_data_frame':cust_bil_to_dim_data_frame,'cust_mstr_prnt_cust_dim_data_frame':cust_mstr_prnt_cust_dim_data_frame}

def main():

	current_date=datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S')
	file_name=sys.argv[0].split('/')[-1].split('.')[0]
	
	log_file_path="{}/{}_{}.log".format(config.log_file_directory,file_name,current_date)
	logging.basicConfig(filename=log_file_path,filemode='w',level=logging.INFO)
		
	#To check if co_nbr argument is passed or not and to format the co_nbr (eg. from '1,10,100' to '001','010','100')	
	if len(sys.argv) > 1 :
		co_nbrs=sys.argv[1].split(',')
		co_nbr_list=', '.join("'{0}'".format(co_nbr.zfill(3)) for co_nbr in co_nbrs)
		logging.info('Company Number - %s', co_nbr_list)
	else:
		logging.info("Processing data for all OpCo's")
		co_nbr_list="'000'"
	
	co_nbr_suffix='_'.join("{0}".format(co_nbr[1:-1]) for co_nbr in co_nbr_list.split(', '))
	hive_context = common_func.initializeSparkHiveContext('CUST_SHIP_TO_DIM')
	hive_context.sql("SET mapred.input.dir.recursive=true")
	
	logging.info('Registering Hive and Redhsift Tables')
	map_dataframe=registerHiveRedshiftTable(hive_context, co_nbr_list)
	SESS_STRT_TM=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	
	logging.info('##################  RI Check Process Started at %s  ##################', datetime.datetime.now())
	
	logging.info('VNDR_DIM - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.vndr_dim_ri_query, 'VNDR', current_date)
	
	logging.info('VNDR_SHIP_FROM_DIM - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.vndr_ship_from_dim_ri_query, 'VNDR_SHIP_FROM', current_date)
	
	logging.info('CUST_BIL_TO_DIM - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.cust_bil_to_dim_ri_query, 'CUST_BIL_TO', current_date)
	
	logging.info('CUST_MSTR_PRNT_CUST_DIM - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.cust_mstr_prnt_cust_dim_ri_query, 'CUST_MSTR_PRNT_CUST', current_date)
	
	logging.info('VNDR_CO_VNDR_REL - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.vndr_co_vndr_ri_query, 'VNDR_CO_VNDR', current_date)
	
	logging.info('VNDR_CO_VNDR_SHIP_FROM - RI Check Started') 		
	common_func.riCheckProcess(logging, hive_context, query_file.vndr_co_vndr_ship_from_ri_query, 'VNDR_CO_VNDR_SHIP_FROM', current_date)
	
	logging.info('ORG_ENTY_DTL - RI Check Started') 	
	#org_enty_dtl_insert_data_frame=hive_context.sql(query_file.org_enty_dtl_ri_query)
	#org_enty_dtl_insert_data_frame.registerTempTable("org_enty_dtl_insert")
	common_func.riCheckProcess(logging, hive_context, query_file.org_enty_dtl_ri_query, 'ORG_ENTY_DTL', current_date)
	
	logging.info('##################  RI Check Process Completed at %s  ##################', datetime.datetime.now())
	
	
	logging.info('##################  Mapping Logic Started at %s ##################', datetime.datetime.now())
	
	logging.info('Registering Intermediate Dataframe, Start Time - %s', datetime.datetime.now())
	cust_ship_to_int_data_frame=hive_context.sql(query_file.cust_ship_to_int_query)
	cust_ship_to_int_data_frame.registerTempTable("CUST_SHIP_TO_INT")			
	cust_ship_to_int_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	for df in list(map_dataframe.values()) :
		df.unpersist()
	
	logging.info('Registering Intermediate Dataframe, End Time - %s', datetime.datetime.now())
			
	################################################ SOURCE RI FILTER ###############################
	#Filter and Insert source records containing data that creates RI records to parent tables
	common_func.riCheckProcess(logging, hive_context, query_file.cust_ship_to_int_ri_query, 'CUST_SHIP_TO_SYG', current_date)
	

	################################################ LOAD ERR ###############################
	#Loading error fact and hist fact tables
	logging.info('Loading Data into LOAD_ERR_FACT table.')
	load_err_fact_insert_data_frame=hive_context.sql(query_file.load_err_fact_query)	
	common_func.loadDataIntoRedshift(logging, 'INSERT', config.dataMartSchema, 'load_err_fact',load_err_fact_insert_data_frame, co_nbr_list,'')


	################################################ LOAD HIST ###############################	
	logging.info('Loading Data into LOAD_HIST_FACT table.')	
	load_hist_fact_insert_query=query_file.load_hist_fact_query.format(SESS_STRT_TM,co_nbr_list, co_nbr_list)
	load_hist_fact_insert_data_frame=hive_context.sql(load_hist_fact_insert_query)
	common_func.loadDataIntoRedshift(logging, 'INSERT', config.dataMartSchema, 'load_hist_fact',load_hist_fact_insert_data_frame, co_nbr_list, '')	

	#Registering spark data frame for Redshift table CUST_SHIP_TO_DIM	
	cust_ship_to_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT * FROM {}.CUST_SHIP_TO_DIM WHERE (CO_SKEY IN ({}) OR '000' IN ({})) AND CUST_SHIP_TO_DIM.CURR_REC_IND='Y' AND CUST_SHIP_TO_DIM.CUST_SHIP_TO_REC_TRM_DT='9999-12-31')".format(config.dataMartSchema,co_nbr_list,co_nbr_list),"cust_ship_to_dim")
				
	cust_ship_to_scd_data_frame=hive_context.sql(query_file.cust_ship_to_scd_query)
	cust_ship_to_scd_data_frame.registerTempTable("CUST_SHIP_TO_SCD")
	cust_ship_to_scd_data_frame.persist(StorageLevel.MEMORY_ONLY)
	cust_ship_to_int_data_frame.unpersist()
	
	################################################ NEW RECORDS - INSERT ###############################

	#CURR_TIME=datetime.datetime.now().strftime('%Y%m%d%H%M%S')
	#SKEY FORMAT - Yymmddhh24mi<OpCoCode><Rownum> 
		
	logging.info('Loading Data into CUST_SHIP_TO_DIM table - New Insert.')	
	cust_ship_to_dim_new_insert_data_frame=hive_context.sql(query_file.cust_ship_to_dim_new_insert_query)
	
	table_name='CUST_SHIP_TO_DIM'
	insert_temp_table_name="{}_INSERT_TEMP_{}".format(table_name,co_nbr_suffix)

	insert_preaction_query = """
			begin;
			drop table if exists {}.{};
			create table {}.{} (like {}.{});
			end;""".format(config.stageSchema, insert_temp_table_name, config.stageSchema, insert_temp_table_name, config.dataMartSchema, table_name)
			
	insert_postaction_query = """
			begin;
			insert into {}.{} select * from {}.{};
			update {}.CUST_SKEY_LKP set CUST_SKEY=B.CUST_SKEY FROM (SELECT CO_SKEY, MAX(CUST_SKEY) AS CUST_SKEY FROM {}.{} GROUP BY CO_SKEY) B WHERE CUST_SKEY_LKP.CO_SKEY=B.CO_SKEY;
			drop table if exists {}.{};
			end;""".format(config.dataMartSchema, table_name, config.stageSchema, insert_temp_table_name, config.dataMartSchema, config.stageSchema, insert_temp_table_name, config.stageSchema, insert_temp_table_name)

	common_func.loadDataIntoRedshift(logging, 'CUSTOM', config.stageSchema, insert_temp_table_name, cust_ship_to_dim_new_insert_data_frame, co_nbr_list, preaction_query=insert_preaction_query, postaction_query=insert_postaction_query)

	#common_func.loadDataIntoRedshift(logging,'INSERT', config.dataMartSchema, 'cust_ship_to_dim_temp2', cust_ship_to_dim_new_insert_data_frame, '', '')
	
	################################################ MAJOR/SCD2 COLS - INSERT/UPDATE ###############################
	
	#LOGIC TO FLAG FULL_UPDATE, FILTER AND MAJOR PROCESS RECORDS
	cust_ship_to_dim_major_data_frame=hive_context.sql(query_file.cust_ship_to_dim_major_query)
	cust_ship_to_dim_major_data_frame.registerTempTable('CUST_SHIP_TO_DIM_MAJOR')
	
	#LOGIC TO DO FULL UPDATE, FOR ERR RECORDS
	
	cust_ship_to_dim_err_full_update_data_frame=hive_context.sql(query_file.cust_ship_to_dim_err_full_update)
	
	logging.info('Loading Data into CUST_SHIP_TO_DIM table - ERR Full Update.')	
	common_func.loadDataIntoRedshift(logging,'UPSERT', config.dataMartSchema, 'cust_ship_to_dim', cust_ship_to_dim_err_full_update_data_frame, co_nbr_list, 'CO_SKEY, CUST_NBR', "CURR_REC_IND='Y' AND SRC_SYS_CD='ERR' AND CUST_SHIP_TO_REC_TRM_DT='9999-12-31'")		
	
	cust_ship_to_dim_major_process_data_frame=hive_context.sql(query_file.cust_ship_to_dim_major_process_query)
	
	logging.info('Loading Data into CUST_SHIP_TO_DIM table - Major Update.')	
	common_func.loadDataIntoRedshift(logging,'UPSERT', config.dataMartSchema, 'cust_ship_to_dim', cust_ship_to_dim_major_process_data_frame, co_nbr_list, 'CO_SKEY, CUST_NBR', "CURR_REC_IND='Y' AND CUST_SHIP_TO_REC_TRM_DT='9999-12-31'")
	
	################################################ MINOR UPDATE ###############################
	
	#Minor Records- Update			
	#cust_ship_to_dim_minor_data_frame=hive_context.sql(query_file.cust_ship_to_dim_minor_query)
	#cust_ship_to_dim_minor_data_frame.registerTempTable('cust_ship_to_dim_minor')
	
	mnr_data_frame=hive_context.sql("""select distinct cust_skey from CUST_SHIP_TO_SCD WHERE MNR='Y' AND CURR_REC_IND='Y' AND SRC_SYS_CD <> 'ERR'""")
	if mnr_data_frame.rdd.isEmpty():
		logging.info('No Minor Update \n')
	else:		
		cust_ship_to_dim_data_frame=common_func.registerRedshiftTable(hive_context, "(SELECT * FROM {}.CUST_SHIP_TO_DIM WHERE (CO_SKEY IN ({}) OR '000' IN ({})) AND CUST_SHIP_TO_DIM.SRC_SYS_CD <> 'ERR')".format(config.dataMartSchema,co_nbr_list,co_nbr_list),"cust_ship_to_dim")
		cust_ship_to_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
		cust_ship_to_dim_minor_update_data_frame=hive_context.sql(query_file.minor_update_query)
		
		logging.info('Loading Data into CUST_SHIP_TO_DIM table - Minor Update.')	
		common_func.loadDataIntoRedshift(logging,'UPSERT', config.dataMartSchema, 'cust_ship_to_dim', cust_ship_to_dim_minor_update_data_frame, co_nbr_list, 'CO_SKEY, CUST_NBR, SRC_SYS_CD, CUST_SKEY, CURR_REC_IND, CUST_SHIP_TO_REC_TRM_DT')
	
	logging.info('CUST_SHIP_TO_DIM Update - Sales Hierarchy')
	
	cust_ship_to_terr_data_frame=hive_context.sql("""select distinct co_skey from CUST_SHIP_TO_INT WHERE out_PK_CHECK_FLAG='N' AND PROC_FLAG='PROCESS'""")
	terr_temp_table_name="cust_ship_to_dim_terr_upd_temp_{}".format(co_nbr_suffix)	
	
	updt_preaction_query = """
			begin;
			drop table if exists {}.{};
			create table {}.{} (co_skey integer);
			end;""".format(config.stageSchema, terr_temp_table_name, config.stageSchema, terr_temp_table_name)
			
	updt_postaction_query = """
	begin;
	create temp table {} (like {}.cust_ship_to_dim);
	insert into {} select A.CUST_SKEY,A.CUST_SHIP_TO_REC_EFF_DT, A.CUST_SHIP_TO_REC_TRM_DT, A.CURR_REC_IND,A.CO_SKEY,A.CUST_NBR,A.VNDR_SKEY,A.VNDR_SHIP_PT_SKEY,A.BIL_TO_SKEY,A.CORP_HIER_PRNT_CUST_SKEY,A.CORP_HIER_MSTR_CUST_SKEY,A.FED_TAX_PAYR_ID,A.SLSPN_CD,A.CUST_NM,A.ADDR_LINE_1_TXT,A.ADDR_LINE_3_TXT,A.ADDR_LINE_2_TXT,A.CTY_NM,A.STT_CD,A.CNTY_NM,A.ZIP_CD,A.CNTRY_CD,A.CUST_ALIAS_NM,A.CUST_CATGY_CD,A.MAJ_CLSS_CD,A.MNR_CLSS_CD,A.SORT_NM,A.APPL_STS_CD,A.ONE_TM_CUST_IND,A.ACT_INAC_IND,A.PAY_TERM_PLCY_CD,A.ACCT_GRP_CD,A.AGE_PLCY_CD,A.TEL_NBR,A.FAX_NBR,A.DLVR_CD,A.SHIP_TO_STOR_NBR,A.ORDR_APRV_RQR_IND,A.ACCT_TYP_CD,A.CORP_TYP_OF_OPER_CD,A.CUISINE_CD,A.PRFL_CREAT_DT,A.DFLT_SBST_TYP_CD,A.DFLT_RSTRC_TYP_CD,A.FRC_SBST_IND,A.DEPT_IND,A.PART_FILL_IND,A.NON_PRFT_IND,A.MISC_TAX_XMPT_IND,A.TERR_CD,D.DEPT_ID,D.DEPT_NM,D.DEPT_EMPLE_ID,D.RGN_ID,D.RGN_NM,D.RGN_EMPLE_ID,D.DIST_ID,D.DIST_NM,D.DIST_EMPLE_ID,D.TERR_NM,D.TERR_EMPLE_ID,A.IMMED_ALLOC_IND,A.CUST_SHIP_TO_STS_ID,A.ORDR_PL_IND,A.CUST_TYP_CD,A.CUST_CMDTY_CD,A.PREV_STS_ID,A.PAY_TERM_CD,A.LCL_TYP_OF_OPER_CD,A.STOP_DT,A.STOP_CNTR_VAL,A.PRC_RULE_NM,A.STOP_CD,A.TERR_OVRD_IND,A.CUST_ENTY_TYP_CD,A.CMDTY_IND,A.KOSHER_CUST_IND,A.PRM_SHIP_TO_NBR,A.DLVR_DFCLT_RTNG_ID,A.PRR_YR_RTNG_CD,A.PRR_MO_RTNG_CD,A.LCL_CUST_RTNG_CD,A.ESYSCO_CUST_IND,A.CUST_CRDT_LMT_BC_AMT,A.UNAPPL_CSH_BAL_BC_AMT,A.OPEN_ITM_BAL_BC_AMT,A.OPEN_ITM_CNT,A.ON_ORDR_AMT_STD_ORDR_BC_AMT,A.ON_ORDR_AMT_DROP_SHIP_BC_AMT,A.ACCT_OPEN_DT,A.ACCT_CLOS_DT,A.FIRST_INVC_DT,A.LST_INVC_DT,A.LST_INVC_AMT_BC_AMT,A.LST_CSH_DT,A.LST_CSH_AMT_BC_AMT,A.AR_TYP_CD,A.CRDT_STOP_APRV_PND_IND,A.TAX_XMPT_IND,A.LAT_COORD_VAL,A.LON_COORD_VAL,A.DIR_OF_LAT_ID,A.DIR_OF_LON_ID,A.SALE_LVL_ID,A.SRC_CREAT_DT,A.INSRT_DTTM, current_timestamp as UPDT_DTTM,A.SRC_SYS_CD,A.CORP_SHIP_TO_STOR_NBR,A.NET_DUE_GRACE_DAY_CD,A.DSCNT,A.DAY_IN_DSCNT_PRD,A.DAY_IN_NET_DUE_PRD,A.TERM_TYP,A.PAY_TERM_PLCY_DESC,A.SAP_IND,A.SAP_CUST_NBR,A.SAP_CUST_NM,A.SAP_ACCT_GRP_NM,A.SYSTEM_SIZE,A.NPD_SYSCO_SEGMENTATION,A.RTLR_FEIN_NBR,A.CUST_BEER_PRMT_NBR 
	from {}.cust_ship_to_dim A
	inner join {}.{} B ON B.CO_SKEY=A.CO_SKEY AND A.SRC_SYS_CD<>'ERR'
	inner join {}.ORG_SALE_HIER_REL D ON A.CO_SKEY=D.CO_SKEY AND TRIM(A.TERR_CD)=D.TERR_CD AND D.CURR_REC_IND = 'Y';
	delete from {}.cust_ship_to_dim using {} temp where cust_ship_to_dim.co_skey=temp.co_skey and cust_ship_to_dim.cust_skey=temp.cust_skey and trim(cust_ship_to_dim.src_sys_cd)=trim(temp.src_sys_cd) and trim(cust_ship_to_dim.cust_nbr)=trim(temp.cust_nbr) and cust_ship_to_dim.curr_rec_ind=temp.curr_rec_ind and cust_ship_to_dim.cust_ship_to_rec_eff_dt=temp.cust_ship_to_rec_eff_dt and cust_ship_to_dim.cust_ship_to_rec_trm_dt=temp.cust_ship_to_rec_trm_dt;
	insert into {}.cust_ship_to_dim select * from {};
	drop table if exists {}.{};
	end;""".format(terr_temp_table_name,config.dataMartSchema,terr_temp_table_name,config.dataMartSchema, config.stageSchema,terr_temp_table_name, config.dataMartSchema, config.dataMartSchema, terr_temp_table_name, config.dataMartSchema,  terr_temp_table_name, config.stageSchema,terr_temp_table_name)
	
	common_func.loadDataIntoRedshift(logging, 'CUSTOM', config.stageSchema, terr_temp_table_name, cust_ship_to_terr_data_frame, co_nbr_list, preaction_query=updt_preaction_query, postaction_query=updt_postaction_query)
	
	'''
	###### To update the details in CUST_XREF_SAP_REL table ####
	
	cust_ship_to_dim_data_frame=common_func.registerRedshiftTable(hive_context,"(SELECT CUST_SKEY, CO_SKEY, CUST_NBR, CUST_NM, PRM_SHIP_TO_NBR, SAP_IND, CURR_REC_IND, SRC_SYS_CD FROM {}.CUST_SHIP_TO_DIM WHERE (CO_SKEY IN ({}) OR '000' IN ({})) AND SRC_SYS_CD NOT IN ('ERR','BT') AND SAP_IND=1 AND CURR_REC_IND='Y')".format(config.dataMartSchema,co_nbr_list,co_nbr_list),"cust_ship_to_dim")
	cust_ship_to_dim_data_frame.persist(StorageLevel.MEMORY_ONLY)
	
	cust_xref_sap_rel_update_data_frame=hive_context.sql("""SELECT SAP_REL.LGCY_CUST_NBR, SAP_REL.LGCY_CO_NBR, SAP_REL.CUST_NBR, SAP_REL.CUST_ACCT_GRP_NM, 
	CASE WHEN CUST.CUST_SKEY IS NOT NULL AND CUST.CUST_NBR LIKE '1%' THEN CUST.CUST_NM ELSE SAP_REL.CUST_ORIG_NM END AS CUST_ORIG_NM, 
	SAP_REL.CUST_TYP_CD, SAP_REL.VNDR_NBR, SAP_REL.INSRT_DTTM, CURRENT_TIMESTAMP AS UPDT_DTTM, SAP_REL.SRC_SYS_CD, SAP_REL.TERR_CD, 
	CASE WHEN CUST.CUST_SKEY IS NOT NULL AND SAP_REL.PRM_SHIP_TO_NBR='' THEN CUST.PRM_SHIP_TO_NBR ELSE SAP_REL.PRM_SHIP_TO_NBR END AS PRM_SHIP_TO_NBR, 
	CASE WHEN PRM_CUST.CUST_SKEY IS NOT NULL AND SAP_REL.PRM_SHIP_TO_NBR <> '' THEN PRM_CUST.CUST_NM ELSE SAP_REL.CUST_PRM_NM END AS CUST_PRM_NM
	FROM rs_CUST_XREF_SAP_REL_mstr SAP_REL
	LEFT OUTER JOIN rs_CUST_SHIP_TO_DIM_mstr CUST ON SAP_REL.CUST_NBR=CUST.CUST_NBR AND SAP_REL.CO_SKEY=CUST.CO_SKEY AND CUST.SAP_IND=1 AND CUST.CURR_REC_IND='Y' AND CUST.SRC_SYS_CD NOT IN ('ERR','BT')
	LEFT OUTER JOIN rs_CUST_SHIP_TO_DIM_mstr PRM_CUST ON SAP_REL.PRM_SHIP_TO_NBR=PRM_CUST.CUST_NBR AND SAP_REL.CO_SKEY=PRM_CUST.CO_SKEY AND PRM_CUST.SAP_IND=1 AND PRM_CUST.CURR_REC_IND='Y' AND PRM_CUST.SRC_SYS_CD NOT IN ('ERR','BT')""")
	
	logging.info("CUST_XREF_SAP_REL Update")
	common_func.loadDataIntoRedshift(logging,'UPSERT', config.dataMartSchema, 'cust_xref_sap_rel', cust_xref_sap_rel_update_data_frame, co_nbr_list, 'LGCY_CUST_NBR, LGCY_CO_NBR, CUST_NBR')
	'''
	logging.info('##################  Mapping Logic Completed at %s ##################', datetime.datetime.now())


if __name__ == "__main__":
	try:
		main()
	except BaseException as error: 
		logging.error(traceback.format_exc())
		raise